#加载包
library(shiny)
library(shinydashboard)
library(recharts)
library(tidyverse)
library(lubridate)
library(plyr)
library(dplyr)
library(curl)
library(ggplot2)
library(graphics)
library(DT)
library(RColorBrewer)
library(showtext)
library(sysfonts)
library(zoo)
library(xts)
library(TTR)
library(quantmod)
library(httpuv)
library(shinycssloaders)
library(forecast)
showtext_auto()

#---XJX----
consum <-
  read.table(
    './7_consumption.csv',
    sep = ',',
    header = T,
    fileEncoding = 'UTF-8-BOM'
  )
consum <- as.data.frame(consum)
consum$MonDeal <- consum$MonDeal * -1
consum$DealTime <- as_datetime(consum$DealTime)
consum <- consum[order(consum$bf_StudentID), ]
names(consum) <- c('消费时间', '消费金额', '学号', '姓名', '性别')
head(consum)

#---ZYQ----
cc <-
  read.table('./cc.csv',
             sep = ',',
             header = T,
             fileEncoding = 'UTF-8-BOM')
cc <- as.data.frame(cc)

k3 <-
  read.table('./k3.csv',
             sep = ',',
             header = T,
             fileEncoding = 'UTF-8-BOM')
k3 <- as.data.frame(k3)

rr <-
  read.table('./rr.csv',
             sep = ',',
             header = T,
             fileEncoding = 'UTF-8-BOM')
rr <- as.data.frame(rr)

pp <-
  read.table('./pp.csv',
             sep = ',',
             header = T,
             fileEncoding = 'UTF-8-BOM')
pp <- as.data.frame(pp)

#---SKY----
kaoqin <- read.table("./3_kaoqin.csv",sep = ',',header = T,fileEncoding = "UTF-8-BOM")
kaoqintype <- read.table("./4_kaoqintype.csv",sep = ',',header = T,fileEncoding = 'UTF-8-BOM')
mydatasky1 <- merge(kaoqin,kaoqintype,by="control_task_order_id",all.x = TRUE)   #左连接两张表
mydatasky <- mydatasky1[,-c(11,12)]
mydatasky$cla_Name1 <- mydatasky$cla_Name
mydatasky$cla_Name1 <- sub(pattern = "白-", replacement = "",mydatasky$cla_Name1)
mydatasky$cla_Name1 <- sub(pattern = "东-", replacement = "",mydatasky$cla_Name1)
mydatasky$cla_Name1 <- substr(mydatasky$cla_Name1, 1, 2)
mydatasky$controler_name.x[mydatasky$controler_name.x=="迟到[移动考勤机]"]<-"迟到_晚到"
mydatasky$controler_name.x <- as.character(mydatasky$controler_name.x)
mydatasky$control_task_name <- as.character(mydatasky$control_task_name)
mydatasky$controler_name.x[mydatasky$ControllerID==99003]<-"早退"
mydatasky$control_task_name[mydatasky$ControllerID==99002]<-"未穿校服"
mydatasky$control_task_name[mydatasky$control_task_order_id==9900100]<-"默认迟到"
mydatasky$control_task_name[mydatasky$control_task_order_id==100000]<-"默认迟到"
mydatasky$control_task_name[mydatasky$control_task_order_id==100200]<-"默认迟到"
mydatasky$control_task_name[mydatasky$ControllerID==99003]<-"默认早退"
mydatasky$controler_name.x[mydatasky$ControllerID==99002]<-"校服校徽"
mydatasky$control_task_name[mydatasky$control_task_order_id==300000]<-"课间操请假"
mydatasky$controler_name.x[mydatasky$control_task_order_id==200000]<-"早退"
mydatasky$controler_name.x[mydatasky$control_task_order_id==200200]<-"请假离校"
mydatasky$controler_name.x[mydatasky$control_task_order_id==200100]<-"校服校徽"

#---ZYJ-QYT----

student<-read_csv("2_student_info.csv")
chengji<-read_csv("5_chengji.csv")
student_chengji2<-read.csv("student_chengji2.csv")
student_chengji4<-read.csv("student_chengji4.csv")
student_chengji<-student %>% 
  left_join(chengji, c("bf_StudentID" = "mes_StudentID"))
student_chengji1<-student_chengji[-which(str_detect(student_chengji$mes_Score,"-1")|str_detect(student_chengji$mes_Score,"-2")|str_detect(student_chengji$mes_Score,"-3")|str_detect(student_chengji$mes_Score,"0")),]
student_chengji3<-student_chengji2%>%
  arrange(mes_Z_Score)
grade<-data.table::fread('./grade.csv',stringsAsFactors = F,encoding = 'UTF-8')
class<-data.table::fread('./class.csv',stringsAsFactors = F,encoding = 'UTF-8')
grade <- as.data.frame(grade)
class <- as.data.frame(class)

bzyj<-read_csv("predict2_zyj.csv")
student_chenjizyj<-read_csv("student_chenjizyj.csv")

czyj <- read.table('czyj.csv',
                   sep = ',',
                   header = T,
                   encoding = "utf-8")

class_compareqyt<-read_csv('./class_subjectqyt.csv')
names(class_compareqyt) <- c('exam_class','exam_numname','subject','level','number','grade')      #改列名
#---WWM----
student_infowwm <-data.table::fread('./student_infowwm.csv',stringsAsFactors = F,encoding = 'UTF-8')
student_infowwm <- as.data.frame(student_infowwm)
ts <-data.table::fread('./ts.csv', stringsAsFactors = F, encoding = 'UTF-8')
ts <- as.data.frame(ts)
ts$weight <- 1
kaoqinwwm <-data.table::fread('./kaoqin.csv',stringsAsFactors = F,encoding = 'UTF-8')
kaoqinwwm <- as.data.frame(kaoqinwwm)
sg <- read.table('./sg.csv',sep = ',',header = T,fileEncoding = 'UTF-8-BOM')
sg$"详情" <- paste0(sg$bf_StudentID,'-',sg$bf_Name,'-',sg$cla_Name_x)  
sg$weight <- 1
sg$target <- ''

#---YLS----
#高一
test <-
  data.table::fread('./test.csv',
                    stringsAsFactors = F,
                    encoding = 'UTF-8')
test131 <-
  data.table::fread('./grade1test13.csv',
                    stringsAsFactors = F,
                    encoding = 'UTF-8')
test151 <-
  data.table::fread('./grade1test15.csv',
                    stringsAsFactors = F,
                    encoding = 'UTF-8')
test231 <-
  data.table::fread('./grade1test23.csv',
                    stringsAsFactors = F,
                    encoding = 'UTF-8')


#高二
test1<-data.table::fread('./test2.csv',
                         stringsAsFactors = F,
                         encoding = 'UTF-8')
test132 <-
  data.table::fread('./grade2test13.csv',
                    stringsAsFactors = F,
                    encoding = 'UTF-8')
test152 <-
  data.table::fread('./grade2test15.csv',
                    stringsAsFactors = F,
                    encoding = 'UTF-8')
test232 <-
  data.table::fread('./grade2test23.csv',
                    stringsAsFactors = F,
                    encoding = 'UTF-8')

#高三
test2<-data.table::fread('./test3.csv',stringsAsFactors = F,encoding = 'UTF-8')
test133<-data.table::fread('./grade3test13.csv',stringsAsFactors = F,encoding = 'UTF-8')
test153<-data.table::fread('./grade3test15.csv',stringsAsFactors = F,encoding = 'UTF-8')
test233 <-data.table::fread('./grade3test23.csv',stringsAsFactors = F,encoding = 'UTF-8')


################################UI##################################
ui <- dashboardPage(
  #-------------------------------  顶部标题----开始  -------------------------------
  dashboardHeader(title = "“数智教育”可视化平台"),
  #-------------------------------  顶部标题----结束  -------------------------------
  
  #-------------------------------  侧边框----开始  ---------------------------------
  dashboardSidebar(sidebarMenu(
    menuItem("学生信息情况", tabName = "student", icon = icon("dashboard")),
    menuItem(
      "学生个人情况",
      icon = icon("user-graduate"),
      startExpanded = TRUE,
      #---------------------xinxi-------------------------
      menuSubItem("个人信息", tabName = "xinxi", icon = icon("th")),
      #-----------------stugrade-----------------------------
      menuSubItem("学生成绩", tabName = "stugrade"),
      #----------------xiaofei------------------
      menuSubItem("学生消费情况", tabName = "xiaofei")
    ),
    
    menuItem("选课情况分布", tabName = "course", icon = icon("th")),
    
    menuItem(
      "群体分布情况",
      icon = icon("school"),
      startExpanded = TRUE,
      #---------------------class_out-----------------
      menuSubItem("高一班级比较", tabName = "class_1"),
      menuSubItem("高二班级比较", tabName = "class_2"),
      #---------------------class_in-----------------
      menuSubItem("高三班级比较", tabName = "class_3"),
      #---------------------kaoqin-----------------
      menuSubItem("学生考勤情况", tabName = "kaoqin"),
      #--------------------grade------------------------
      menuSubItem("历史成绩", tabName = "grade")
      #-------------
    ),
    
    menuItem("平台使用说明", tabName = "instra", icon = icon("edit"))
    
   
  )),
  #-------------------------------- 侧边框----结束  ---------------------------------
  
  #-------------------------------  正文----开始    ---------------------------------
  dashboardBody(
    tabItems(
      #-------------xinxi-----------------
      tabItem(
        tabName = "xinxi",
        fluidRow(
          column(width = 12,
                 selectInput(
                   "学号", "请选择学号:",
                   choices = unique(student_infowwm$bf_StudentID)
                 )),
          
          box(
            title = "基本信息",
            status = "primary",
            height = 300,
            solidHeader = TRUE ,
            
            div(
              style = "float: left;width:120px;margin:40px 0 0 20px;",
              div(style = 'padding:0 10px 10px 0;', span(textOutput('学号'))),
              div(style = 'padding-bottom:10px;', span(textOutput('姓名'))),
              div(style = 'padding-bottom:8px;', span(textOutput('班级'))),
              div(style = 'padding-bottom:8px;', span(textOutput('出生日期'))),
              div(style = 'padding-bottom:10px;', span(textOutput('民族')))
            ),
            div(
              style = "float: left;width:120px;margin:40px 0 0 20px;",
              
              div(style = 'padding-bottom:10px;', span(textOutput('生源地'))),
              div(style = 'padding-bottom:10px;', span(textOutput('户籍类型'))),
              div(style = 'padding-bottom:10px;', span(textOutput('政治面貌'))),
              div(style = 'padding-bottom:10px;', span(textOutput('退学'))),
              div(style = 'padding-bottom:10px;', span(textOutput('寝室号')))
            ),
            div(style = "float: right;margin:30px 0px 0 0px", imageOutput("sex", height = 2))
            
          ),
          box(
            title = "任课老师情况",
            status = "primary",
            height = 300,
            solidHeader = TRUE ,
           div(style="margin-top:-80px;",eChartOutput("teacher",height = 390)) 
          ),
          
          
          valueBoxOutput("chidao", width = 3),
          valueBoxOutput("zaotui", width = 3),
          valueBoxOutput("xiaofu", width = 3),
          valueBoxOutput("qingjia", width = 3)
          
        ),
        fluidRow(
          box(
            plotOutput("plot4zyj")%>%withSpinner(type = 4),
            title = '学生各次考试平均总分的趋势',
            width = 12,
            status = 'primary',
            solidHeader = T,
            collapsible = TRUE
          )
        )
      ),
      #-------------stugrade  -----------------
      tabItem(
        tabName = "stugrade",
        fluidRow(
          box(
            status = "primary",
            solidHeader = T,
            collapsible = T,
            width = 12,
            height = 700,
            title = p(textOutput('y1qyt')),
            background = NULL,
            column(
              background = NULL,
              width = 4,
              # 黄绿色背景
              selectInput("IDqyt", "请选择学生学号：",
                          choices = unique(student_chengji4$bf_StudentID))
            ),
            # 插入文本框
            column(
              background = NULL,
              width = 4,
              selectInput(
                "exam_numnameqyt",
                "请选择考试名称：",
                choices = unique(student_chengji4$exam_numname)
              )
            ),
            # 插入文本框
            column(background = NULL, width = 7, p(textOutput('baocuoqyt'))),
            plotOutput("gplot_1qyt")%>%withSpinner(type = 4),
            br(),
            br(),
            br(),
            br(),
            br(),
            br(),
            div(style = 'padding:0 5px 0 15px;font-family: 楷体;font-weight: bold;', p("1、本图为某位学生的所有考试根据不同的科目展示的标准化后的成绩。")),
            div(style = 'padding:0 5px 0 15px;font-family: 楷体;font-weight: bold;', p("2、蓝色折线所连接的点为本次考试的标准化后的成绩，其他点用以做对比。"))
          )
        ),
        valueBoxOutput("kemuBoxqyt", width = 4),
        valueBoxOutput("nianjiBoxqyt", width = 4),
        
        valueBoxOutput("banjiBoxqyt", width = 4),
        fluidRow(
          box(
            status = "primary",
            solidHeader = T,
            collapsible = T,
            width = 6,
            height = 650,
            title = '学生考试成绩',
            background = NULL,
            column(
              background = NULL,
              width = 4,
              selectInput(
                "chengjiIDqyt",
                "请选择学生学号：",
                choices = unique(student_chengji4$bf_StudentID)
              )
            ),
            # 插入文本框
            column(
              background = NULL,
              width = 8,
              selectInput(
                "chengji_numnameqyt",
                "请选择考试名称：",
                choices = unique(student_chengji4$exam_numname)
              )
            ),
            # 插入文本框
            column(background = NULL, width = 7, p(textOutput('baocuo3qyt'))),
            plotOutput("gplot2qyt")%>%withSpinner(type = 4)
          ),
          box(
            height = 650,
            status = "primary",
            solidHeader = T,
            collapsible = T,
            width = 6,
            background = NULL,
            title = '学生各科等第分布',
            column(
              background = NULL,
              width = 4,
              selectInput(
                "id3zyj",
                "请选择学生学号：",
                choices = unique(student_chenjizyj$mes_StudentID)
              )
            ),
            column(
              width = 8,
              background = NULL,
              selectInput(
                "exam_namezyj",
                "请选择考试名称：",
                choices = unique(student_chenjizyj$exam_numname)
              )
            ),
            p(textOutput('text2zyj')),
            plotOutput("plot5zyj")%>%withSpinner(type = 4),
            br(),
            br(),
            br(),
            br(),
            br(),
            div(style = 'padding:0 5px 0 15px;font-family: 楷体;font-weight: bold;', p("1、本图为某位学生在某次考试中所考科目的等第分布。")),
            div(style = 'padding:0 5px 0 15px;font-family: 楷体;font-weight: bold;', p("2、等第划分来自于数据的补充材料，根据学生成绩的占比划分为5等第。"))
          ) ,
          
          fluidRow(
            box(
              height = 630,
              status = "primary",
              solidHeader = T,
              collapsible = T,
              width = 6,
              background = NULL,
              title = p(textOutput('yqyt')),
              column(
                width = 6,
                background = NULL,
                selectInput(
                  "student_IDqyt",
                  "请选择学生学号：",
                  choices = unique(student_chengji2$bf_StudentID)
                )
              ),
              column(
                width = 6,
                background = NULL,
                selectInput(
                  "sub_nameqyt",
                  "请选择考试科目：",
                  choices = unique(student_chengji2$mes_sub_name)
                )
              ),
              p(textOutput('baocuo1qyt')),
              plotOutput("plot1qyt")%>%withSpinner(type = 4) # 文本输出标题
            ),
            # 最小化按钮，洋红色背景
            box(
              height = 630,
              status = "primary",
              solidHeader = T,
              collapsible = T,
              width = 6,
              background = NULL,
              title = p(textOutput("captionzyj")),
              column(
                background = NULL,
                width = 6,
                selectInput("id_zyj", "请选择学生学号：", choices = unique(bzyj$mes_StudentID))
              ),
              column(
                width = 6,
                background = NULL,
                selectInput("subname_zyj", "请选择考试科目：", choices = unique(bzyj$mes_sub_name))
              ),
              p(textOutput('textzyj')),
              plotOutput("plot1zyj")%>%withSpinner(type = 4)
            )
          )
        )
        
      ),
      #------------xiaofei------------------
      tabItem(
        tabName = "xiaofei",
        fluidRow(
          box(
            width = 4,
            background = NULL,
            selectInput("sno", "选择学号:",
                        choices = unique(consum$学号))
          ),
          infoBoxOutput("高消费月份记录", width = 8)
        ),
        tabItem(
          tabName = "info",
          fluidRow(
            valueBoxOutput("月均消费额", width = 3),
            valueBoxOutput('日均消费数', width = 3),
            valueBoxOutput("次均消费额", width = 3),
            infoBoxOutput("贫困生预测", width = 3)
          ),
          fluidRow(
            box(
              title = "周总消费"
              ,
              status = "primary"
              ,
              solidHeader = TRUE
              ,
              collapsible = TRUE
              ,
              eChartOutput("plot1_xjx")%>%withSpinner(type = 4)
              ,
              div(
                style = "float: left;width:95%;margin:20px 0 0 10px",
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、此图展示该同学周总消费趋势，横坐标指的是该年的第几周；")),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、同时可以点击右边图例进行折线图柱状图切换。"))
              )
            ),
            box(
              title = "月总消费"
              ,
              status = "primary"
              ,
              solidHeader = TRUE
              ,
              collapsible = TRUE
              ,
              eChartOutput("plot2_xjx")%>%withSpinner(type = 4)
              ,
              div(
                style = "float: left;width:95%;margin:20px 0 0 10px",
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、此图展示该同学月总消费趋势，横坐标指的是该年的第几月；")),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、同时可以点击右边图例进行折线图柱状图切换。"))
              )
            )
          ),
          fluidRow(
            box(
              title = "实时消费"
              ,
              status = "primary"
              ,
              solidHeader = TRUE
              ,
              collapsible = TRUE
              ,
              plotOutput("plot3_xjx", height = "250px", width = '95%')%>%withSpinner(type = 4)
              ,
              div(
                style = "float: left;width:95%;margin:20px 0 0 10px",
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、此图展示该同学实时消费记录，横坐标指某年某月某日某时刻；")),
                div(style = 'padding:-5px 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、该图可以轻易看出高消费时刻，便于家长及老师了解学生消费情况"))
              )
            ),
            
            box(
              title = "预测月消费"
              ,
              status = "primary"
              ,
              solidHeader = TRUE
              ,
              collapsible = TRUE
              ,
              plotOutput("plot6_xjx", width = "95%", height = "250px")%>%withSpinner(type = 4)
              ,
              div(
                style = "float: left;width:95%;margin:20px 0 0 10px",
                div(
                  style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                  p("1、此图展示的是预测的月总消费情况，蓝线是预测的五个月的消费情况，黑线是已知数据，虚线是残差走向；")
                )
              )
            )
          )
          ),
          h2("消费明细"),
          #比赛要求有消费明细
          dataTableOutput('view_xjx')
      ),
      #-------------kaoqin-----------------
      tabItem(
        tabName = "kaoqin",
        fluidRow(
          column(width = 3,
                 selectInput("学期","请选择学期:",
                             choices = unique(mydatasky$qj_term)
                 )),
          column(width = 3,
                 selectInput("年级","请选择年级:",
                             choices = unique(mydatasky$cla_Name1)
                 )),
          column(width = 3,
                 selectInput("班级","请选择班级:",
                             choices = unique(mydatasky$cla_Name)
                 )),
          br(),
          column(width = 3,
                 actionButton("update", "确定",width = 190)
          )),
        fluidRow(
          valueBoxOutput("全校缺勤人数",width=3),
          valueBoxOutput("年级早退比例",width=3),
          valueBoxOutput("年级迟到比例",width=3),
          valueBoxOutput("本年级缺勤人数",width=3)),
        fluidRow(
          box(width=6,
              title = "三个年级学生考勤情况"
              ,status = "primary"
              ,solidHeader = TRUE 
              ,collapsible = TRUE 
              ,plotOutput("attendanceqingkuang", height = "250px")%>%withSpinner(type = 4)
          )
          ,box(width=6,
               title = "本年级学生考勤情况"
               ,status = "primary"
               ,solidHeader = TRUE 
               ,collapsible = TRUE 
               ,plotOutput("attendanceleixing", height = "250px")%>%withSpinner(type = 4)
          )),
        fluidRow(
          box(width=6,
              title = "本班学生考勤类型"
              ,status = "primary"
              ,solidHeader = TRUE 
              ,collapsible = TRUE 
              ,plotOutput("banjikaoqin", height = "250px")%>%withSpinner(type = 4)
          ),
          
          
          valueBoxOutput("本班缺勤人数",width=3),
          valueBoxOutput("本班迟到人数",width=3),
          valueBoxOutput("本班未穿校服人数",width = 3),
          valueBoxOutput("本班课间操请假人数",width=3),
          valueBoxOutput("本班请假离校人数",width=3),
          valueBoxOutput("本班未戴校徽人数",width=3)
        ),
        fluidRow(
          box(width = 200,
              title = "本学期各班学生考勤"
              ,status = "primary"
              ,solidHeader = TRUE 
              ,collapsible = TRUE 
              ,plotOutput("gebanjikaoqin", height = "350px")%>%withSpinner(type = 4)
          )
        )
      ),
      #-------------course  -----------------
      tabItem(tabName = "course",
              fluidRow(
                box(
                  title = "各班选课分布",
                  height = '550px',
                  width = '1200px',
                  status = "primary",
                  solidHeader = TRUE ,
                  eChartOutput("xk1")%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:95%;margin:20px 0 0 10px",
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、此图展示高三各班的选课分布，可以从图例对目标课程进行选择；")),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                      "2、总体来看，高三（1）班~高三（7）班偏理科，高三（8）班~高三（10）班偏文科。"
                    ))
                  )
                ),
                box(
                  title = "选课重叠情况",
                  status = "primary",
                  solidHeader = TRUE ,
                  collapsible = TRUE ,
                  eChartOutput("xk2", height = '380px')%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:95%;margin:20px 0 0 10px",
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                      "1、此图展示高三各班的选课重叠情况，可以从图例对目标班级进行选择，查看选课情况；"
                    )),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、各班各科目选课重叠情况多样，“化学”、“生物”两门课重叠率较高。"))
                  )
                ),
                box(
                  title = "每个班每门课对应的选课占比",
                  status = "primary",
                  solidHeader = TRUE ,
                  collapsible = TRUE ,
                  eChartOutput("xk3", height = '380px')%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:95%;margin:20px 0 0 10px",
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                    div(
                      style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                      p(
                        "1、此图展示高三各班各科目的选课人数及占比，可以对各班级进行比较，了解各班级及全年级的分布情况，每一圈表示一个班级；"
                      )
                    ),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、各班级各科目的选课占比大致相同，“物化生”三门课的选课率超过了六成。"))
                  )
                ),
                box(
                  title = "全年级7选3人数及占比",
                  status = "primary",
                  solidHeader = TRUE ,
                  collapsible = TRUE ,
                  eChartOutput("xk4", height = '380px')%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:95%;margin:20px 0 0 10px",
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                      "1、此图展示7选3的各种组合的人数及占比，点击右边工具栏，可以转换成金字塔图，进行排序展示；"
                    )),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                      "2、选择“物化生”的人数最多，达到了16.11%，选择“历政物”组合的人数最少。"
                    ))
                  )
                ),
                box(
                  title = "各科目总选择人数",
                  status = "primary",
                  solidHeader = TRUE ,
                  collapsible = TRUE ,
                  eChartOutput("xk5", height = '380px')%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:95%;margin:20px 0 0 10px",
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                    div(
                      style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                      p("1、该河流图展示各科目的选择人数统计结果，根据结果可以适当的调整教学班的开设、各科教师的人数；")
                    ),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                      "2、需求最大的是“物理”、“化学”，“生物”老师，历史教学班可以根据人数调整开设个数。"
                    ))
                  )
                )
              )),
      #-------------grade  -----------------
      tabItem(tabName = "grade",
              fluidRow(
                column(
                  4,
                  selectInput(
                    "class_name_zyq",
                    "请选择班级",
                    choices = unique(cc$cla_Name),
                    selected = "白-高二(01)"
                  )
                ),
                column(
                  4,
                  selectInput(
                    "kemu_zyq",
                    "请选择科目",
                    choices = unique(cc$mes_sub_name),
                    selected = "数学"
                  )
                ),
                column(4, uiOutput("extype_zyq")),
                fluidRow(
                  column(
                    8,
                    box(
                      height = '550px',
                      width = '1300px',
                      title = p(textOutput("caption_zyq")),
                      status = "primary",
                      solidHeader = TRUE ,
                      collapsible = TRUE ,
                      tabsetPanel(
                        tabPanel("最高分最低分趋势", plotOutput("hight_zyq")%>%withSpinner(type = 4)),
                        tabPanel("比例图", plotOutput("percent_zyq")%>%withSpinner(type = 4)),
                        
                        plotOutput("line_zyq")%>%withSpinner(type = 4)
                      )
                    )
                  ),
                  column(
                    4,
                    br(),
                    br(),
                    valueBoxOutput("max_zyq", width = 11),
                    br(),
                    valueBoxOutput("min_zyq", width = 11),
                    br(),
                    div(
                      style = "float: left;width:950px;margin:20px 0 0 10px",
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                          p('1、由’选择班级‘选择框和’选择科目‘选择框')),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                          p("确定折线图(最高最低分趋势图)，橙色的折线代")),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                          p('表最高分趋势，红色的折线代表最低分趋势。')),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                          p("2、由’选择班级‘选择框和’选择科目‘选择框")),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                          p("和’选择考试类型‘选择框确定条形图(比例图)。")),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                          p("3、其中上面的最高分和最低分为该班级该次考试")),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;',
                          p("该个科目的最高最低分"))
                    )
                  )
                )
              ),
              br(),
              br(),
              fluidRow(column(
                12,
                box(
                  height = '600px',
                  width = '1300px',
                  title = "各班级各分数段人数",
                  status = "primary",
                  solidHeader = TRUE ,
                  collapsible = TRUE ,
                  column(
                    4,
                    selectInput(
                      "number_zyq",
                      "考试科目数",
                      choices = c(1, 2, 3, 4, 5, 6, 7, 8, 9),
                      selected = "9"
                    )
                  ),
                  column(
                    4,
                    selectInput(
                      "nianji_zyq",
                      "请选择年级",
                      choices = c('高一', '高二', '高三'),
                      selected = "高三"
                    )
                  ),
                  column(
                    4,
                    selectInput(
                      "type_zyq",
                      "请选择考试类型",
                      choices = unique(k3$exam_numname),
                      selected = "2016学年度第一学期期末考试"
                    )
                  ),
                  p(textOutput('baocuo2zyq')),plotOutput("tuzongfen_zyq")%>%withSpinner(type = 4)
                )
              )),
              fluidRow(column(
                6,
                box(
                  height = '600px',
                  width = '1300px',
                  title = "各班级各分数段排名",
                  status = "primary",
                  solidHeader = TRUE ,
                  collapsible = TRUE ,
                  column(
                    4,
                    selectInput(
                      "fanwei_zyq",
                      "分数段",
                      choices = unique(k3$range),
                      selected = "500~700"
                    )
                  ),
                  p(textOutput('baocuo3zyq')), plotOutput("zf_zyq")%>%withSpinner(type = 4)
                )
              ),
              column(
                6,
                box(
                  height = '600px',
                  width = '1300px',
                  title = p('班级科目等第分布情况'),
                  status = "primary",
                  solidHeader = TRUE ,
                  collapsible = TRUE ,
                  column(
                    4,
                    selectInput(
                      "class_name_zyq2",
                      "请选择班级",
                      choices = unique(rr$cla_Name),
                      selected = unique(rr$cla_Name)[1]
                    )
                  ),
                  column(
                    8,
                    selectInput(
                      "type_zyq2",
                      "请选择考试类型",
                      choices = unique(rr$exam_numname),
                      selected = unique(rr$exam_numname)[1]
                    )
                  ),
                  p(textOutput('baocuozyq')),plotOutput("pie_zyq")%>%withSpinner(type = 4)
                  
                ),
                
                br()
              ))
              ),
      
      #-------------class_1  -----------------
      tabItem(tabName = "class_1",
              fluidRow(
                column(
                  width = 3,
                  status = "primary",
                  background = NULL,
                  selectInput(
                    "class_namey1",
                    "请选择班级",
                    choices = unique(test$cla_Name),
                    selected = "东-高一(01)"
                  )
                ),
                column(
                  width = 3,
                  status = "primary",
                  background = NULL,
                  selectInput(
                    "ksy1",
                    "请选择考试类型",
                    choices = unique(test$exam_numname),
                    selected = "2018—1学期期中考试"
                  )
                ),
                column(
                  width = 3,
                  status = "primary",
                  background = NULL,
                  selectInput(
                    "kmy1",
                    "请选择科目",
                    choices = unique(test$mes_sub_name),
                    selected = "数学"
                  )
                ),
                column(
                  div(style = 'padding:22px 5px 0 20px;'),
                  width = 2,
                  status = "primary",
                  background = NULL,
                  actionButton("updatey1", "确定")
                ),
                ###新加的box，关于学生排名叠装柱状图
                column(
                  12,
                  
                  box(
                    title = "考试总分情况"
                    ,
                    status = "primary"
                    ,
                    solidHeader = TRUE
                    ,
                    collapsible = TRUE ,
                    br(),
                    br(),
                   
                    plotOutput("sum")%>%withSpinner(type = 4),
                    br(),
                    div(
                      style = "float: left;width:950px;margin:20px 0 0 10px",
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、红色直线表示本班总分的平均分；")),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、蓝色直线表示年级总分的平均分。"))
                    ), 
                    br()
                  ),
                  
                  valueBoxOutput("总分最高分", width = 6),
                  valueBoxOutput("总分最低分", width = 6),
                  valueBoxOutput("总分平均分", width = 6),
                  valueBoxOutput("总分方差", width = 6),
                  valueBoxOutput("总分标准差", width = 6),
                  valueBoxOutput("年级总分平均分", width = 6)
                ),
                
                ###新加的box
                box(
                  title = tagList(shiny::icon("list-alt"), "本班学生本次考试总分排名"),
                  solidHeader = T,
                  width = 12,
                  collapsible = T,
                  DT::dataTableOutput("table")
                ),
                
                
                column(
                  width = 12,
                  box(
                    width = 6,
                    title = "本班学生本科目本次考试情况",
                    
                    status = "primary"
                    ,
                    solidHeader = TRUE
                    ,
                    collapsible = TRUE
                    ,
                    br(),
                    br(),
                    plotOutput("cj")%>%withSpinner(type = 4),
                    div(
                      style = "float: left;width:950px;margin:20px 0 0 10px",
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、红色直线表示本班总分的平均分；")),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、蓝色直线表示年级总分的平均分。"))
                    )
                    
                  ),
                  
                  valueBoxOutput("班级最高分", width = 6),
                  valueBoxOutput("班级最低分", width = 6),
                  valueBoxOutput("班级平均分", width = 6),
                  valueBoxOutput("班级方差", width = 6),
                  valueBoxOutput("班级标准差", width = 6),
                  valueBoxOutput("年级平均分", width = 6)
                ),
                
                column(
                  width = 12,
                  box(
                    width = 6,
                    title = "本次考试本科目等第情况",
                    status = "primary"
                    ,
                    solidHeader = TRUE
                    ,
                    collapsible = TRUE
                    ,
                    plotOutput("dd")
                  ),
                  
                  box(
                    width = 6,
                    title = "各班本次考试该科目的平均分"
                    ,
                    status = "primary"
                    ,
                    solidHeader = TRUE
                    ,
                    collapsible = TRUE
                    ,
                    plotOutput("gmean")%>%withSpinner(type = 4)
                  )
                ),
                
                ##新加的box
                box(
                  title = tagList(shiny::icon("list-alt"), "本班学生本次考试本科目排名"),
                  solidHeader = T,
                  width = 12,
                  collapsible = T,
                  DT::dataTableOutput("tabled")
                )
              )
              ),
      # -------------class_2  -----------------
      tabItem(tabName = "class_2",
              fluidRow(
                column(width=3,status = "primary",background=NULL,
                       selectInput(
                         "class_namey2",
                         "请选择班级",
                         choices = unique(test1$cla_Name),
                         selected = "白-高二(01)"
                       )),
                column(width=3,status = "primary",background=NULL,
                       selectInput(
                         "ksy2",
                         "请选择考试类型",
                         choices = unique(test1$exam_numname),
                         selected = "2017学年度第二学期期末考试"
                       )
                ),
                column(width=3,status = "primary",background=NULL,
                       selectInput(
                         "kmy2",
                         "请选择科目",
                         choices = unique(test1$mes_sub_name),
                         selected = "数学"
                       )),
                column(div(style = 'padding:22px 5px 0 20px;'),width=2,status = "primary",background=NULL,
                       actionButton("updatey2", "确定")
                ),
                column(
                  12,
                  
                  box(
                    title = "考试总分情况"
                    ,
                    status = "primary"
                    ,
                    solidHeader = TRUE
                    ,
                    collapsible = TRUE ,
                    br(),
                    br(),
                    br(),
                    plotOutput("sumy2")%>%withSpinner(type = 4),
                    div(
                      style = "float: left;width:950px;margin:20px 0 0 10px",
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、红色直线表示本班总分的平均分；")),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p( "2、蓝色直线表示年级总分的平均分。"
                      ))
                    )
                  ),
                  
                  
                  valueBoxOutput("总分最高分y2",width=6),
                  valueBoxOutput("总分最低分y2",width=6),
                  valueBoxOutput("总分平均分y2",width=6),
                  valueBoxOutput("总分方差y2",width=6),
                  valueBoxOutput("总分标准差y2",width=6),
                  valueBoxOutput("年级总分平均分y2",width=6)),
                
                box(
                  title=tagList(shiny::icon("list-alt"),"本班学生本次考试总分排名"),solidHeader=T,width=12,
                  collapsible=T,DT::dataTableOutput("tabley2")
                ),
                column(width=12,
                       box(
                         width=6,
                         title = "本班学生本科目本次考试情况",
                         br(),
                         br(),
                         
                         status = "primary"
                         ,solidHeader = TRUE 
                         ,collapsible = TRUE 
                         ,plotOutput("cjy2")%>%withSpinner(type = 4),
                         div(
                           style = "float: left;width:950px;margin:20px 0 0 10px",
                           div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                           div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、红色直线表示本班总分的平均分；")),
                           div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p( "2、蓝色直线表示年级总分的平均分。"
                           ))
                         )
                       ),
                       
                       valueBoxOutput("班级最高分y2",width=6),
                       valueBoxOutput("班级最低分y2",width=6),
                       valueBoxOutput("班级平均分y2",width=6),
                       valueBoxOutput("班级方差y2",width=6),
                       valueBoxOutput("班级标准差y2",width=6),
                       valueBoxOutput("年级平均分y2",width=6)),
                column(width=12,
                       box(width=6,
                           title = "本次考试本科目等第情况",
                           status = "primary"
                           ,solidHeader = TRUE 
                           ,collapsible = TRUE 
                           ,plotOutput("ddy2")%>%withSpinner(type = 4)
                       ), 
                       
                       box(
                         width=6,
                         title = "各班本次考试该科目的平均分"
                         ,status = "primary"
                         ,solidHeader = TRUE 
                         ,collapsible = TRUE 
                         ,plotOutput("gmeany2")%>%withSpinner(type = 4)
                       )),
                
                box(
                  title=tagList(shiny::icon("list-alt"),"本班学生本次考试本科目排名"),solidHeader=T,width=12,
                  collapsible=T,DT::dataTableOutput("tabledy2")
                )
              )
              
      ),
      #----class_3------
     
      tabItem(tabName = "class_3",
              fluidRow(
                
                column(width=3,status = "primary",background=NULL,
                       selectInput(
                         "class_namey3",
                         "请选择班级",
                         choices = unique(test2$cla_Name),
                         selected = "高三(01)"
                       )),
                column(width=3,status = "primary",background=NULL,
                       selectInput(
                         "ksy3",
                         "请选择考试类型",
                         choices = unique(test2$exam_numname),
                         selected = "2017学年度第一学期期末考试"
                       )
                ),
                column(width=3,status = "primary",background=NULL,
                       selectInput(
                         "kmy3",
                         "请选择科目",
                         choices = unique(test2$mes_sub_name),
                         selected = "数学"
                       )),
                column(div(style = 'padding:22px 5px 0 20px;'),width=2,status = "primary",background=NULL,
                       actionButton("updatey3", "确定")
                ),
                column(
                  12,
                  
                  box(
                    title = "考试总分情况"
                    ,
                    status = "primary"
                    ,
                    solidHeader = TRUE
                    ,
                    collapsible = TRUE ,
                    
                    br(),
                    br(),
                    plotOutput("sumy3")%>%withSpinner(type = 4),
                    div(
                      style = "float: left;width:950px;margin:20px 0 0 10px",
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、红色直线表示本班总分的平均分；")),
                      div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p( "2、蓝色直线表示年级总分的平均分。"
                      ))
                    )
                  ),
                  
                  
                  valueBoxOutput("总分最高分y3", width = 6),
                  valueBoxOutput("总分最低分y3", width = 6),
                  valueBoxOutput("总分平均分y3", width = 6),
                  valueBoxOutput("总分方差y3", width = 6),
                  valueBoxOutput("总分标准差y3", width = 6),
                  valueBoxOutput("年级总分平均分y3", width = 6)
                ),
                
                box(
                  title = tagList(shiny::icon("list-alt"), "本班学生本次考试总分排名"),
                  solidHeader = T,
                  width = 12,
                  collapsible = T,
                  DT::dataTableOutput("tabley3")
                ),
                column(width=12,
                       box(
                         width=6,
                         title = "本班学生本科目本次考试情况",
                         
                         status = "primary"
                         ,
                         solidHeader = TRUE
                         ,
                         collapsible = TRUE ,
                         br(),
                         br(),
                         
                         plotOutput("cjy3")%>%withSpinner(type = 4),
                         div(
                           style = "float: left;width:950px;margin:20px 0 0 10px",
                           div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;'),
                           div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、红色直线表示本班总分的平均分；")),
                           div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p( "2、蓝色直线表示年级总分的平均分。"
                           ))
                         )
                       ),
                       
                       valueBoxOutput("班级最高分y3", width = 6),
                       valueBoxOutput("班级最低分y3", width = 6),
                       valueBoxOutput("班级平均分y3", width = 6),
                       valueBoxOutput("班级方差y3", width = 6),
                       valueBoxOutput("班级标准差y3", width = 6),
                       valueBoxOutput("年级平均分y3", width = 6)),
                column(width=12,
                       box(
                         width=6,
                         title = "本次考试本科目等第情况",
                         status = "primary"
                         ,
                         solidHeader = TRUE
                         ,
                         collapsible = TRUE
                         ,
                         plotOutput("ddy3")%>%withSpinner(type = 4)
                       ),
                       
                       box(
                         width=6,
                         title = "各班本次考试该科目的平均分"
                         ,
                         status = "primary"
                         ,
                         solidHeader = TRUE
                         ,
                         collapsible = TRUE
                         ,
                         plotOutput("gmeany3")%>%withSpinner(type = 4)
                       )),
                
                box(
                  title = tagList(shiny::icon("list-alt"), "本班学生本次考试本科目排名"),
                  solidHeader = T,
                  width = 12,
                  collapsible = T,
                  DT::dataTableOutput("tabledy3")
                )
              )
             ),
      #----student--------
      tabItem(tabName = "student",
              fluidRow(
                box(
                  title = "男女比例情况",
                  status = "primary",
                  height = 440,
                  solidHeader = TRUE ,
                  eChartOutput("nannv", height = 300)%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:90%;margin:20px 0 0 10px",
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;', p("图表说明：")),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                      "上图为2018-2019学年第一学期三个年级的男女比例情况，该校男女比例较协调。"
                    ))
                  )
                ),
                tabBox(
                  title = "消费对比",
                  id = "tabbox1",
                  selected = "Tab1",
                  
                  #width = 6,
                  side = "right",
                  # side表示tablePanel的顺序，right表示反向
                  tabPanel(
                    title = "按周",
                    value = "Tab1",
                    # value与tabBox内的selected匹配
                    "不同性别平均每周消费总金额对比",
                    br(),
                    imageOutput("plot4_xjx", width = 550, height = "360px")%>%withSpinner(type = 4)
                  ),
                  # 内容
                  tabPanel(
                    title = "按月",
                    value = "Tab2",
                    "不同性别平均每月消费总金额对比",
                    br(),
                    imageOutput("plot5_xjx", width = "90%", height = "360px")%>%withSpinner(type = 4)
                  )
                ),
                
                box(
                  title = "除浙江省的生源分布",
                  status = "primary",
                  height = 720,
                  solidHeader = TRUE ,
                  eChartOutput("shengfen", height = 500)%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:90%;margin:20px 0 0 10px",
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;', p("图表说明：")),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、对原始数据进行处理，将学生家庭住址一栏进行统计；")),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、基于图标完整性，对于未涉及省份，用0表示其数量；")),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                      "3、为显示除“浙江省”外，其余各省份的学生情况，将其约定为0，用辐射圈标识浙江省学生数量。"
                    ))
                    
                  )
                ),
                
                box(
                  title = "浙江省内生源分布",
                  status = "primary",
                  height = 720,
                  solidHeader = TRUE ,
                  eChartOutput("dishi", height = 500)%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:90%;margin:20px 0 0 10px",
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;', p("图表说明：")),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("1、由于浙江省学生数量与其他省份相差较大，因此做单独处理；")),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p("2、经过数据处理发现，浙江省的学生分布也极不均匀，主要集中在“宁波市”；")),
                    div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                      "3、为显示除“宁波市”外，其余各区县的学生情况，将其约定为0，用辐射圈标识宁波市学生数量。"
                    ))
                  )
                ),
                
                box(
                  title = "优秀学生矩形树图",
                  status = "primary",
                  height = 430,
                  solidHeader = TRUE ,
                  column(width = 7,
                         selectInput(
                           "ks_w", "",
                           choices = unique(sg$exam_numname)
                         )),
                  column(width = 3,
                         selectInput(
                           "nj_w", "",
                           choices = unique(sg$gra_Name)
                         )),
                  
                  eChartOutput("yx_w", height = 300)%>%withSpinner(type = 4),
                  div(
                    style = "float: left;width:90%;margin:48px 0 0 10px",
                    div(style = 'padding:0 5px 0 70px;font-family: 楷体;font-weight: bold;', p("矩阵树图展示选择条件下考试年级前5%的学生。"))
                   
                )
                
                ),
                
                box(
                  title = "某班学生名单",
                  status = "primary",
                  height = 430,
                  solidHeader = TRUE ,
                  column(width = 6,
                         selectInput(
                           "bj_w", "",
                           choices = unique(sg$cla_Name_x)
                         )),
                  div(style="margin-top: -400px;", eChartOutput("bjmd_w", height = 500))
                  
                ),
                
                box(width = 12,height = 600, title = '各等级学生数对比',status = 'primary',solidHeader = TRUE,
                    fluidRow(
                      column(width = 4,
                             selectInput("subject", "输入考试科目",
                                         choices = unique(class_compareqyt$subject))), # 插入文本框
                      column(width=4,
                             selectInput("exam_numname", "输入考试名字",
                                         choices = unique(class_compareqyt$exam_numname))),
                      column(width = 4, selectInput("dataset", "选择要观察的年级", 
                                                    choices = c("高一", "高二", "高三"))),
                      
                      eChartOutput("echart1qyt")%>%withSpinner(type = 4), # 文本输出标题
                      br(),
                      br(),
                      br(),
                      div(style = 'padding:0 5px 0 15px;font-family: 楷体;font-weight: bold;', p("1、本图为某个年级某次考试某个科目的各等级学生数对比。")),
                      div(style = 'padding:0 5px 0 15px;font-family: 楷体;font-weight: bold;', p("2、等级划分是通过数据中的等第以及赛题中所提供的表格说明划分的")),
                      div(style = 'padding:0 5px 0 15px;font-family: 楷体;font-weight: bold;', p("3、由于等级划分为多个学校同时划分，而数据为一个学校的，所以考试中可能仅有部分等级")),
                      width = 12, status ='primary',  
                      collapsible = FALSE)
                )
              )
              ),
      #----great-------
      tabItem(tabName = "instra",
              fluidRow(
              div(
                style = "float: left;width:90%;margin:20px 0 0 10px",
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:19px;', p("“数智教育”数据可视化平台使用说明")),
                # div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:17px;', p(
                #   "内容简介："
                # )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:16px;', p(
                  "一、学生信息情况"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  "1、男女比例情况图显示2018-2019学年第一学期三个年级的男女比例情况；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  "2、消费对比图可以选择按月或按周显示不同性别消费对比折线图；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  "3、地图显示非浙江省生源分布图、浙江省生源分布图；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  "4、优秀学生矩形树图反映各次考试，各年级前5%的优秀学生的“学号-姓名-班级:成绩”；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  "5、以力导向图的形式展示班级学生名单，可在规定范围内自由拖拽；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  "6、按班级、考试名称和科目的划分显示各等级学生总数对比情况。"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:16px;', p(
                  "二、学生个人情况"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  " 1、个人信息界面：包括基本个人信息、任课老师详情、缺勤次数、期中期末考试平均总分趋势的可视化图像。"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  "  2、学生成绩界面："
                )),
                div(style = 'padding:0 5px 0 5px;font-family: 楷体;font-weight: bold;', p(
                  "（1）按照考试得出的标准化成绩可视化图像、班级排名、年级排名、薄弱学科；"
                )),
                div(style = 'padding:0 5px 0 5px;font-family: 楷体;font-weight: bold;', p(
                  "（2）按照考试得出所有学科的等级、原始分的可视化图像；"
                )),
                div(style = 'padding:0 5px 0 5px;font-family: 楷体;font-weight: bold;', p(
                  "（3）展示学生单科成绩，并建立模型 画出未来成绩趋势预测图。"
                )),
                
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                  "3、学生消费界面："
                )),
                div(style = 'padding:0 5px 0 5px;font-family: 楷体;font-weight: bold;', p(
                  "（1）月总消费及周总消费可视化图像，并计算该生月均消费、日均消费、次均消费；"
                )),
                div(style = 'padding:0 5px 0 5px;font-family: 楷体;font-weight: bold;', p(
                  "（2）通过机器学习建立回归模型来预测学生贫困情况（贫困生判定标准：使用一卡通消费频率高；月均消费金额小；次消费金额小。）"
                )),
                div(style = 'padding:0 5px 0 5px;font-family: 楷体;font-weight: bold;', p(
                  "（3）根据月总消费情况显示出消费过高的具体月份；"
                )),
                div(style = 'padding:0 5px 0 5px;font-family: 楷体;font-weight: bold;', p(
                  "（4）学生的实时消费记录可视化图像，并利用时间序列的ARIMA模型预测后五个月的月总消费情况；"
                )),
                div(style = 'padding:0 5px 0 5px;font-family: 楷体;font-weight: bold;', p(
                  "（5）学生的消费明细表格"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:16px;', p(
                  "三、选课情况分布"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "1、高三各个班级的选课情况；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "2、展示选课的重叠情况（通过该图可发现热门7选3选课趋势）；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "3、显示所有学科在每班的选课占比情况，没一圈代表一个班，可横向，纵向对比；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "4、三种任意学科组合选择的人数及占比情况，点击工具条可变成金字塔图，展示从高到底的组合排序；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "5、显示各学科选择总人数（可以看出热门单科）;"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "6、以上图形右边或者右上方的工具箱能够变换图形类型。"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:16px;', p(
                  "四、群体分布情况"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "1、三个年级成绩展示:"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（1）总分情况：按照年级、班级和考试名称显示本班的总分图像，该次考试的排名明细和成绩最大值、最小值、均值、方差、标准差及年级总平均分；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（2）单科情况：根据班级、考试名称和科目，显示具体班级具体考试具体科目的成绩图像及方差均值等指标，以及各班该考试科目的平均分和不同等级人数，并显示班级本科目成绩的排名明细。"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "2、学生考勤界面:"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（1）根据学期年级和班级显示不同的考勤情况，反映该学期的各种考勤情况的人数以及比例；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（2）三个年级学生考勤情况条形图反映三个年级学生的不同考勤情况，包括迟到、请假、早退和未穿校服未带校徽的各年级总人数；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（3）本年级学生考勤情况条形图反映所选年级的不同的考勤情况的人数；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（4）本班学生考勤类型图反映本班不同考勤情况，右边的方框表示本班的缺勤、迟到未穿校服、未戴校徽、课间操请假以及请假离校人数；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（5）本学期各班人数考勤图反映了所选学期和年级中不同的班级的考勤情况的人数。"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "3、历史成绩界面:"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（1）根据选择的班级、考试名称、科目显示不同考试时间本科目的最低分最高趋势图并显示最高分最低分的具体值；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（2）各班各分数段人数图根据选择的科目数、年级、考试名称显示每个班各分数段的总人数分布情况；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（3）各班级各分数段排名图显示每个班每次考试总分分数段的人数情况；"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight:bold', p(
                  "（4）班级科目等第分布情况图显示每次考试每个科目不同等级的总人数分布情况。"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:16px;', p(
                  "PS:特殊说明："
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;', p(
                "由于数据的脱敏处理以及数据的缺失，导致一部分选择条件可能匹配不到相关的数据。"
                )),
                div(style = 'padding:0 5px 0 0;font-family: 楷体;font-weight: bold;font-size:16px;', p(
                  "希望该平台能够为您提供帮助，谢谢使用！"
                ))
              
                
              )
              )
              )
    )
  )
  )


################################server##################################
server <- function(input, output, session) {
  #---------------------xinxi-------------------------
  
  output$'teaC' <- renderInfoBox({
    infoBox(
      title = '语文老师',
      paste0(
        filter(ts, bf_StudentID == input$'学号' &
                 sub_Name == "语文")$bas_Name
      ),
      icon = icon("university"),
      color = "blue",
      fill = TRUE
    )
  })
  
  output$'teaM' <- renderInfoBox({
    infoBox(
      title = '数学老师',
      paste0(
        filter(ts, bf_StudentID == input$'学号' &
                 sub_Name == "数学")$bas_Name
      ),
      icon = icon("university"),
      color = "blue",
      fill = TRUE
    )
  })
  
  output$'teaE' <- renderInfoBox({
    infoBox(
      title = '外语老师',
      paste0(
        filter(ts, bf_StudentID == input$'学号' &
                 sub_Name == "英语")$bas_Name
      ),
      icon = icon("university"),
      color = "blue",
      fill = TRUE
    )
  })
  
  output$'teaT' <- renderInfoBox({
    infoBox(
      title = '体育老师',
      paste0(
        filter(ts, bf_StudentID == input$'学号' &
                 sub_Name == "体育")$bas_Name
      ),
      icon = icon("university"),
      color = "blue",
      fill = TRUE
    )
  })
  
  
  output$'chidao' <- renderInfoBox({
    infoBox(
      title = '迟到',
      paste0(dim(
        filter(
          kaoqinwwm,
          bf_studentID == input$'学号' &
            control_task_order_id	== 9900100
        )
      )[1]),
      icon = icon("university"),
      color = "yellow",
      fill = TRUE
    )
  })
  
  output$'zaotui' <- renderInfoBox({
    infoBox(
      title = '早退',
      paste0(dim(
        filter(
          kaoqinwwm,
          bf_studentID == input$'学号' &
            control_task_order_id	== 9900300
        )
      )[1]),
      icon = icon("university"),
      color = "yellow",
      fill = TRUE
    )
  })
  
  output$'xiaofu' <- renderInfoBox({
    infoBox(
      title = '没穿校服',
      paste0(dim(
        filter(
          kaoqinwwm,
          bf_studentID == input$'学号' &
            control_task_order_id	== 9900200
        )
      )[1]),
      icon = icon("university"),
      color = "yellow",
      fill = TRUE
    )
  })
  
  output$'qingjia' <- renderInfoBox({
    infoBox(
      title = '请假',
      paste0(dim(
        filter(
          kaoqinwwm,
          bf_studentID == input$'学号' &
            control_task_order_id	== 200200
        )
      )[1]),
      icon = icon("university"),
      color = "yellow",
      fill = TRUE
    )
  })
  
  
  
  output$'学号' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$bf_StudentID
  })
  
  output$'姓名' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$bf_Name
  })
  
  output$'出生日期' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$bf_BornDate
  })
  
  output$'民族' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$bf_nation
  })
  
  output$'班级' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$cla_Name
  })
  
  output$'生源地' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$bf_NativePlace
  })
  
  output$'户籍类型' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$Bf_ResidenceType
  })
  
  output$'政治面貌' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$bf_policy
  })
  
  output$'退学' <- renderText({
    filter(student_infowwm, bf_StudentID == input$'学号')$bf_leaveSchool
  })
  
  output$'寝室号' <- renderText({
    paste0(
      "寝室号",
      "(",
      filter(student_infowwm, bf_StudentID == input$'学号')$bf_qinshihao,
      ")"
    )
  })
  
  output$sex <- renderImage({
    if (filter(student_infowwm, bf_StudentID == input$'学号')$bf_sex == '男') {
      return(
        list(
          src = "./boy.png",
          filetype = "image/png",
          alt = "This is a boy",
          width = 150,
          height = 180
        )
      )
    } else if (filter(student_infowwm, bf_StudentID == input$'学号')$bf_sex ==
               '女') {
      return(
        list(
          src = "./girl.png",
          filetype = "image/png",
          alt = "This is a girl",
          width = 150,
          height = 180
        )
      )
    }
  }, deleteFile = FALSE)
  
 
  
  output$teacher <- renderEChart({
    a <- filter(ts, bf_StudentID == input$'学号')
    a$b <- paste0(a$sub_Name,': ',a$bas_Name)
    echartr(a, c(bf_StudentID, b),weight,sub_Name,type='force',sub='arrow')%>%
      setLegend(show = F)%>%
      setToolbox(show = F)
  })
  
  
  output$pmqs <- renderEChart({
    echartr(xk,  班级,  人数,  课程, type = 'vbar') %>% setSymbols('emptycircle') %>% setTheme('dark')
  })
  
  
  datasetinput1zyj <- eventReactive(input$学号, {
    czyj[czyj$mes_StudentID == input$'学号', ]
  }, ignoreNULL = FALSE)
  
  output$plot4zyj <- renderPlot({
    ggplot(data = datasetinput1zyj(),
           mapping = aes(x = exam_sdate, y = avg_score)) +
      geom_line(color = 'blue',
                linetype = 1,
                group = 1) +
      geom_point(
        shape = 23,
        size = 3,
        mapping = aes(x = exam_sdate, y = avg_score, fill = EXAM_KIND_NAME)
      ) +
      labs(x = '考试时间', y = '平均总成绩', title = '学生平均总分趋势') +
      theme(
        plot.title = element_text(
          size = rel(1.5),
          color = 'black',
          vjust = 0.5,
          hjust = 0.5
        ),
        axis.title.x = element_text(
          colour = "black",
          vjust = 0.5,
          size = 17
        ),
        axis.title.y = element_text(
          colour = "black",
          hjust = 0.5,
          angle = 90,
          size = 17
        ),
        axis.text = element_text(colour = "black", size = 11),
        axis.text.x = element_text(
          angle = 60,
          size = 11,
          hjust = 1
        )
      )
  })
  
  #-----------------stugrade---------
  output$gplot_1qyt <- renderPlot({
    datasetInput1qyt <-
      student_chengji4[student_chengji4$bf_StudentID == input$IDqyt, ]
    # 内部可以插入计算代码
    datasetInputqyt <-
      student_chengji4[student_chengji4$bf_StudentID == input$IDqyt &
                         student_chengji4$exam_numname == input$exam_numnameqyt, ]
    if (is.na(datasetInputqyt[1, 1]) == F) {
      return(
        ggplot(
          data = datasetInput1qyt,
          mapping = aes(x = mes_sub_name, y = mes_Z_Score, group = 1)
        ) +
          theme(legend.position = "none") +
          geom_point(
            mapping = aes(color = exam_numname),
            size = 4
          ) +
          geom_smooth(data = datasetInputqyt, se = FALSE) +
          labs(x = "考试科目", y = "标准化后的成绩")
      )
    }
  })
  output$gplot2qyt <- renderPlot({
    # 内部可以插入计算代码
    datasetInput4qyt <-
      student_chengji4[student_chengji4$bf_StudentID == input$chengjiIDqyt &
                         student_chengji4$exam_numname == input$chengji_numnameqyt, ]
    if (is.na(datasetInput4qyt[1, 1]) == F) {
      return(
        ggplot(data = datasetInput4qyt) +
          geom_bar(
            mapping = aes(x = mes_sub_name, y = mes_Score, fill = mes_sub_name),
            stat = "identity"
          ) +
          geom_text(
            mapping = aes(x = mes_sub_name, y = mes_Score, label = mes_Score),
            vjust = -0.3,
            color = 'black'
          ) +
          theme(legend.position = "none") +
          labs(x = "考试科目", y = "成绩")
      )
    }
  })
  output$plot1qyt <- renderPlot({
    # 内部可以插入计算代码
    datasetInput2qyt <-
      student_chengji2[student_chengji2$bf_StudentID == input$student_IDqyt &
                         student_chengji2$mes_sub_name == input$sub_nameqyt, ]
    
    if (is.na(datasetInput2qyt[1, 1]) == F) {
      return(
        ggplot(
          data = datasetInput2qyt,
          mapping = aes(x = exam_date, y = mes_Score, group = 1)
        ) +
          geom_line(color = 'blue', size = 1) +
          geom_point(
            mapping = aes(fill = exam_date),
            shape = 23,
            size = 3
          )    +
          labs(x = "考试时间", y = "成绩") +
          theme(
            legend.position = "none",
            axis.text.x = element_text(angle = 60, hjust = 1),
            axis.title.x = element_text(
              face = 'bold',
              colour = "black",
              vjust = 0.5,
              size = 17
            ),
            axis.title.y = element_text(
              face = 'bold',
              colour = "black",
              hjust = 0.5,
              angle = 90,
              size = 17
            ),
            axis.text = element_text(colour = "black", size = 10)
          )
      )
    }
  })
  
  # 给output对象增加menu变量
  output$myMenu <- renderMenu({
    # 以menu形式输出
    mymenu_list <- apply(menudata, 1, function(row) {
      menuItem(text = row[["text"]],
               tabName = row[["tabnames"]],
               icon = icon(row[["iconname"]]))
    })
    sidebarMenu(.list = mymenu_list)
  })
  output$summary <- renderPrint({
    dataset <- datasetInput()
    summary(dataset)
  })
  output$kemuBoxqyt <- renderValueBox({
    dataset1qyt <-
      student_chengji3[student_chengji3$bf_StudentID == input$IDqyt &
                         student_chengji3$exam_numname == input$exam_numnameqyt, ]
    if (is.na(dataset1qyt[1, 1]) == F) {
      return(infoBox(
        "本次考试薄弱项",
        br(),
        paste0(dataset1qyt$mes_sub_name[[1]]),
        icon = icon("book"),
        color = "light-blue",
        fill = FALSE
      ))
    }
    else if (is.na(dataset1qyt[1, 1]) == T) {
      return(paste0('无考试'))
    }
  })
  output$nianjiBoxqyt <- renderValueBox({
    infoBox(
      "年级排名 ",
      br(),
      paste0(
        filter(
          grade,
          grade$bf_StudentID == input$IDqyt,
          grade$exam_numname == input$exam_numnameqyt
        )$grade_ranking,
        "/",
        filter(
          grade,
          grade$bf_StudentID == input$IDqyt,
          grade$exam_numname == input$exam_numnameqyt
        )$number
      ),
      icon = icon("list"),
      color = "light-blue",
      fill = FALSE
    )
  })
  
  output$banjiBoxqyt <- renderValueBox({
    infoBox(
      "班级排名",
      br(),
      paste0(
        filter(
          class,
          class$bf_StudentID == input$IDqyt,
          class$exam_numname == input$exam_numnameqyt
        )$class_ranking,
        "/",
        filter(
          class,
          class$bf_StudentID == input$IDqyt,
          class$exam_numname == input$exam_numnameqyt
        )$number
      ),
      icon = icon("bar-chart"),
      color = "light-blue",
      fill = FALSE
    )
  })
  
  x1qyt <- reactive({
    paste(input$IDqyt, '号学生考试成绩(标准化)分布')
  })
  output$y1qyt <- renderText(x1qyt())
  
  output$baocuoqyt <- renderText({
    datasetInputqyt <-
      student_chengji4[student_chengji4$bf_StudentID == input$IDqyt &
                         student_chengji4$exam_numname == input$exam_numnameqyt, ]
    if (is.na(datasetInputqyt[1, 1]) == T) {
      return(paste0(input$IDqyt, '号学生没有参加本次考试'))
    }
  })
  output$baocuo3qyt <- renderText({
    datasetInput4qyt <-
      student_chengji4[student_chengji4$bf_StudentID == input$chengjiIDqyt &
                         student_chengji4$exam_numname == input$chengji_numnameqyt, ]
    if (is.na(datasetInput4qyt[1, 1]) == T) {
      return(paste0(input$chengjiIDqyt, '号学生没有参加本次考试'))
    }
  })
  output$baocuo1qyt <- renderText({
    datasetInput2qyt <-
      student_chengji2[student_chengji2$bf_StudentID == input$student_IDqyt &
                         student_chengji2$mes_sub_name == input$sub_nameqyt, ]
    
    if (is.na(datasetInput2qyt[1, 1]) == T) {
      return(paste0(input$student_IDqyt, '号学生没有本科目的成绩'))
    }
  })
  
  
  
  xqyt <- reactive({
    paste(input$student_IDqyt, '号学生', input$sub_nameqyt, '考试成绩分布图')
  })
  output$yqyt <- renderText(xqyt())
  
  xzyj <- reactive({
    paste(input$id3zyj, '号学生在', input$exam_namezyj, '中各科等第分布')
  })
  
  output$yzyj <- renderText(xzyj())
  
  output$text2zyj <- renderText({
    datasetinput3zyj <-
      student_chenjizyj[student_chenjizyj$mes_StudentID == input$id3zyj &
                          student_chenjizyj$exam_numname == input$exam_namezyj, ]
    
    if (is.na(datasetinput3zyj[1, 1]) == T) {
      return(paste(input$id3zyj, '号学生未参加', input$exam_namezyj))
    }
  })
  output$plot5zyj <- renderPlot({
    datasetinput3zyj <-
      student_chenjizyj[student_chenjizyj$mes_StudentID == input$id3zyj &
                          student_chenjizyj$exam_numname == input$exam_namezyj, ]
    
    if (is.na(datasetinput3zyj[1, 1]) == F) {
      return(
        ggplot(data = datasetinput3zyj) +
          geom_point(
            shape = 25,
            size = 3,
            mapping = aes(x = mes_sub_name, y = dengdi, fill = dengdi)
          ) +
          labs(x = '考试科目', y = '等第') +
          theme(
            axis.text.x = element_text(angle = 60, hjust = 1),
            axis.title.x = element_text(
              face = 'bold',
              colour = "black",
              vjust = 0.5,
              size = 17
            ),
            axis.title.y = element_text(
              face = 'bold',
              colour = "black",
              hjust = 0.5,
              angle = 90,
              size = 17
            ),
            axis.text = element_text(colour = "black", size = 13)
          )
      )
    }
  })
  
  
  
  zyj <- reactive({
    paste(input$id_zyj, '号学生', input$subname_zyj, "未来成绩趋势图")
  })
  
  output$captionzyj <- renderText(zyj())
  
  output$textzyj <- renderText({
    datasetInput2zyj <-
      bzyj[bzyj$mes_StudentID == input$id_zyj &
             bzyj$mes_sub_name == input$subname_zyj, ]
    if (is.na(datasetInput2zyj[1, 1]) == T) {
      return(paste(input$id_zyj, '号学生考试次数太少，不进行预测'))
    }
  })
  
  output$plot1zyj <- renderPlot({
    datasetInput2zyj <-
      bzyj[bzyj$mes_StudentID == input$id_zyj &
             bzyj$mes_sub_name == input$subname_zyj, ]
    
    if (is.na(datasetInput2zyj[1, 1]) == F) {
      return(
        ggplot(
          data = datasetInput2zyj,
          mapping = aes(x = number, y = mes_Score)
        ) +
          
          stat_smooth(mapping = aes(x = number, y = mes_Score)) +
          scale_x_continuous(breaks = seq(1, 5, 1)) +
          labs(x = "考试时间", y = "成绩") +
          theme(
            legend.position = "none",
            axis.text.x = element_text(angle = 60, hjust = 1),
            axis.title.x = element_text(
              face = 'bold',
              colour = "black",
              vjust = 0.5,
              size = 17
            ),
            axis.title.y = element_text(
              face = 'bold',
              colour = "black",
              hjust = 0.5,
              angle = 90,
              size = 17
            ),
            axis.text = element_text(colour = "black", size = 13)
          )
        
      )
    }
  })
  
  #-----------------xiaofei----------
  condition2 <- reactive({
    month <-
      tapply(datasetInput_xjx()$消费金额,
             format(datasetInput_xjx()$消费时间, "%Y-%m"),
             sum)
    month <- as.data.frame.table(month)
    month$timeNumber <- (1:nrow(month))
    names(month) <- c("time", "money", 'timenumber')
    month$money <- as.numeric(month$money)
    s <- month[month$money > 500, ]
    if (nrow(s) == 0) {
      text = '无过高记录'
    } else {
      A <- paste(s[1:nrow(s), 1], collapse = " ")
      text = A
    }
  })
  output$'高消费月份记录' <- renderInfoBox({
    infoBox(
      title = "过高消费月份",
      value = condition2(),
      color = 'light-blue',
      fill = FALSE
    )
  })
  
  
  condition <- reactive({
    daynumber <- length(unique(as_date(datasetInput_xjx()$消费时间)))
    number <- length(unique(datasetInput_xjx()$消费时间))
    monthnumber <- length(unique(month(datasetInput_xjx()$消费时间)))
    dn <-
      round(sum(count(filter(
        consum,   学号   == input$sno
      )$消费时间)$freq) / daynumber)
    nm <-
      round(sum(filter(consum,   学号   == input$sno)$ 消费金额) / number)
    mm <-
      round(sum(filter(consum,   学号   == input$sno)$消费金额) / monthnumber)
    if (dn >= 2 &
        nm <= 10 &
        mm <= 400 &
        mm >= 240) {
      text = '贫困生'
    } else {
      text = '非贫困生'
    }
  })
  output$'贫困生预测' <- renderInfoBox({
    infoBox(
      title = "贫困情况",
      value = condition(),
      color = 'light-blue',
      fill = FALSE  
      )
  })
  
  
  datasetInput_xjx <- eventReactive(input$sno, {
    consum[consum$学号   == input$sno, ]
  }, ignoreNULL = FALSE)
  output$view_xjx = renderDataTable(datasetInput_xjx(),
                                    options = list(pageLength = 10))
  
  output$'日均消费数' <- renderInfoBox({
    daynumber <- length(unique(as_date(datasetInput_xjx()$消费时间)))
    infoBox('日均消费数/次',
            paste0(round(sum(
              count(filter(consum,   学号   == input$sno)$消费时间)$freq
            ) / daynumber)),
            color = 'light-blue',
            fill = FALSE
            )
  })
  
  output$'次均消费额' <- renderInfoBox({
    number <- length(unique(datasetInput_xjx()$消费时间))
    infoBox('次均消费额/元',
            paste0(round(sum(
              filter(consum,   学号   == input$sno)$ 消费金额
            ) / number)),
            color = 'light-blue',
            fill = FALSE)
  })
  
  output$'月均消费额' <- renderInfoBox({
    monthnumber <- length(unique(month(datasetInput_xjx()$消费时间)))
    infoBox('月均消费额/元',
            paste0(round(sum(
              filter(consum,   学号   == input$sno)$消费金额
            ) / monthnumber)),
            color = 'light-blue',
            fill = FALSE)
  })
  
  output$plot1_xjx <- renderEChart({
    week <-
      tapply(datasetInput_xjx()$消费金额,
             format(datasetInput_xjx()$消费时间, "%Y-%U"),
             sum)
    week <- as.data.frame.table(week)
    names(week) <- c("time", "money")
    week$time <- as.character(week$time)
    echartr(week,
            time,
            money,
            type = 'line',
            subtype = list('fill')) %>% setSymbols('none') %>% setDataZoom()%>%
      setToolbox(pos = 2)
  })
  output$plot2_xjx <- renderEChart({
    month <-
      tapply(datasetInput_xjx()$消费金额,
             format(datasetInput_xjx()$消费时间, "%Y-%m"),
             sum)
    month <- as.data.frame.table(month)
    names(month) <- c("time", "money")
    month$time <- as.character(month$time)
    month$money <- as.numeric(month$money)
    number <- 500
    echartr(
      month,
      time,
      money,
      type = 'line',
      subtype = list('fill'),
      markLine = t(c(number, 'Mean', "average", F))
    ) %>% setSymbols('none') %>% setDataZoom()%>%
      setToolbox(pos = 2)
  })
  output$plot3_xjx <- renderPlot({
    xxt <-
      xts(x = datasetInput_xjx()$消费金额,
          order.by = as.POSIXct(datasetInput_xjx()$消费时间))
    chartSeries(xxt, theme = "white")
    
  })
  
  
  output$plot4_xjx <- renderImage({
    imagefile <- 'E:/data/week.png'
    list(src = imagefile)
  }, deleteFile = FALSE)
  
  output$plot5_xjx <- renderImage({
    imagefile <- 'E:/data/month.png'
    list(src = imagefile)
  }, deleteFile = FALSE)
  
  output$plot6_xjx <- renderPlot({
    month2 <-
      tapply(datasetInput_xjx()$消费金额,
             format(datasetInput_xjx()$消费时间, "%Y-%m"),
             sum)
    month2 <- as.data.frame.table(month2)
    names(month2) <- c("time", "money")
    month2$time <- as.character(month2$time)
    month2$money <- as.numeric(month2$money)
    s <- as.numeric(substr(month2[1, 1], 1, 4))
    t <- as.numeric(substr(month2[1, 1], 7, 7))
    a2 <- ts(month2$money,
             start = c(s, t),
             frequency = 12)
    conarima <- arima(a2, order = c(1, 2, 0), method = "ML")
    conforecast <-
      forecast:::forecast.Arima(conarima, h = 5, level = c(99.5))
    forecast:::plot.forecast(
      conforecast,
      xlab = "时间",
      ylab = "月总消费",
      shaded = FALSE,
      PI = TRUE
    )
  })
  #-------------------course------------------
  output$xk1 <- renderEChart({
    xk <- data.table::fread('./xkrsfb.csv', encoding = 'UTF-8')
    names(xk) <- c('班级', '课程', '人数')
    xk$班级  <- as.character(xk$班级)
    xk <- as.data.frame(xk)
    echartr(xk,  班级,  人数,  课程, type = 'vbar') %>% setSymbols('emptycircle')
  })
  
  output$xk2 <- renderEChart({
    xk <- data.table::fread('./xkrsfb.csv', encoding = 'UTF-8')
    names(xk) <- c('班级', '课程', '人数')
    xk$班级  <- as.character(xk$班级)
    xk <- as.data.frame(xk)
    echartr(xk,  课程,  人数,  班级, type = 'radar', subtype = list('fill')) %>%
      setToolbox(lang = 'en', pos = 2)
  })
  
  output$xk3 <- renderEChart({
    xk <- data.table::fread('./xkrsfb.csv', encoding = 'UTF-8')
    names(xk) <- c('班级', '课程', '人数')
    xk$班级  <- as.character(xk$班级)
    xk <- as.data.frame(xk)
    echartr(xk,  课程,  人数,  班级, type = 'pie', subtype = list('fill')) %>%
      setToolbox(lang = 'en', pos = 2)
    
  })
  
  output$xk4 <- renderEChart({
    xk <- data.table::fread('./7x3.csv', encoding = 'UTF-8')
    xk <- xk[2:34, ]
    xk <- as.data.frame(xk)
    xk$V1 <- as.factor(xk$V1)
    echartr(xk, V1, V2, type = 'ring') %>%
      setTitle('7选3分布情况', pos = 11) %>%
      setLegend(show = FALSE) %>%
      setTT(trigger = 'item')
    
  })
  
  
  output$xk5 <- renderEChart({
    xk <- data.table::fread('./xkrs.csv', encoding = 'UTF-8')
    xk <- as.data.frame(xk)
    names(xk) <- c('课程', '人数')
    echartr(xk,  课程,  人数, type = 'area') %>%
      setTitle('科目总人数') %>%
      setSymbols('emptycircle')
    
  })
  
  
  #----------grade-------
  kk_zyq <- reactive({
    cc %>%
      filter(cc$mes_sub_name == input$kemu_zyq &
               cc$cla_Name == input$class_name_zyq)
  })
  output$extype_zyq <- renderUI({
    selectInput(
      "extype1_zyq",
      "请选择考试类型",
      choices = kk_zyq()$exam_numname,
      selected = '2016学年度第一学期期末考试'
    )
  })
  y_zyq <- reactive({
    paste(input$class_name_zyq,
          input$kemu_zyq,
          "最高分最低分趋势图")
  })
  datasetInput_zyq <- reactive({
    cc[cc$mes_sub_name == input$kemu_zyq &
         cc$cla_Name == input$class_name_zyq &
         cc$exam_numname == input$extype1_zyq,]
  })
  output$caption_zyq <- renderText(y_zyq())
  pp_zyq <- reactive({
    pp %>%
      filter(pp$class_Name == input$class_name_zyq,
             pp$mes_sub_name == input$kemu_zyq)
  })
  output$hight_zyq <- renderPlot({
    ggplot(data <-
             pp_zyq()) +
      geom_line(
        mapping = aes(x = exams_date, y = min_grade,group=1),
        linetype = "dashed",
        size = 1,
        colour = "red"
      ) +
      geom_line(
        mapping = aes(x = exams_date, y = max_grade,group=1),
        linetype = "dashed",
        size = 1,
        colour = "orange"
      ) +
      ylab("分数") +
      xlab("考试时间")
  })
  
  output$percent_zyq <- renderPlot({
    ggplot(data = datasetInput_zyq(),
           mapping = aes(
             x = factor(datasetInput_zyq()$level),
             y = (..count..) / sum(..count..),
             fill = factor(datasetInput_zyq()$level)
           )) +
      geom_bar() +
      xlab("等第") +
      ylab("比例") +
      labs(fill = "等第")
  })
  output$max_zyq <- renderInfoBox({
    infoBox('最高分',
            br(),
            paste0(max(
              datasetInput_zyq()$mes_Score, value = 0
            )),
            color = "blue",
            fill = FALSE)
  })
  output$min_zyq <- renderInfoBox({
    infoBox('最低分',
            br(),
            paste0(min(
              datasetInput_zyq()$mes_Score, value = 150
            )),
            color = "blue",
            fill = FALSE)
  })
  # data3_zyq <- reactive({
  #   rr[rr$exam_numname == input$type_zyq2 &
  #        rr$cla_Name == input$class_name_zyq2,]
  # })
  # output$pie_zyq <-  renderPlot({
  #   ggplot(data = data3_zyq(), aes(mes_sub_name)) +
  #     geom_bar(aes(fill = level)) +
  #     coord_polar(theta = "x") +
  #     xlab('科目') +
  #     ylab('人数') +
  #     labs(fill = "等第")
  # })
  output$baocuozyq <- renderText({
    data3_zyq <-   rr[rr$exam_numname == input$type_zyq2 &
                        rr$cla_Name == input$class_name_zyq2,]
    if (is.na(data3_zyq[1, 1]) == T) {
      return(paste0('此条件无匹配结果（数据不完整）'))
    }
  })
  
  output$pie_zyq <-  renderPlot({
    data3_zyq <-   rr[rr$exam_numname == input$type_zyq2 &
                        rr$cla_Name == input$class_name_zyq2,]
    if(is.na(data3_zyq[1,1])==F){return(ggplot(data = data3_zyq, aes(mes_sub_name)) +
                                          geom_bar(aes(fill = level)) +
                                          coord_polar(theta = "x") +
                                          xlab('科目') +
                                          ylab('人数') +
                                          labs(fill = "等第")
    )}
  })
  # datainput3_zyq <- reactive({
  #   k3 %>%
  #     filter(
  #       k3$number == input$number_zyq &
  #         k3$nianji == input$nianji_zyq &
  #         k3$exam_numname == input$type_zyq
  #     )
  # })
  # output$tuzongfen_zyq <-  renderPlot({
  #   ggplot(datainput3_zyq(), aes(x = class_Name, fill = range)) +
  #     geom_bar(stat = 'count',
  #              position = "dodge",
  #              width = 0.5) +
  #     #调色盘
  #     ylab("人数") +
  #     xlab("班级") +
  #     labs(fill = "总分范围")
  #   
  # })
  
  output$baocuo2zyq <- renderText({
    
    datainput3_zyq <- 
      k3 %>%
      filter(
        k3$number == input$number_zyq &
          k3$nianji == input$nianji_zyq &
          k3$exam_numname == input$type_zyq
      )
    
    if (is.na(datainput3_zyq[1, 1]) == T) {
      return(paste0('此条件无匹配结果（数据不完整）'))
    }
  })
  
  output$tuzongfen_zyq <-  renderPlot({
    datainput3_zyq <- 
      k3 %>%
      filter(
        k3$number == input$number_zyq &
          k3$nianji == input$nianji_zyq &
          k3$exam_numname == input$type_zyq
      )
    if(is.na(datainput3_zyq[1,1])==F){return(
      ggplot(datainput3_zyq, aes(x = class_Name, fill = range)) +
        geom_bar(stat = 'count',
                 position = "dodge",
                 width = 0.5) +
        ylab("人数") +
        xlab("班级") +
        labs(fill = "总分范围")
    )}
  })
  # datainput4_zyq <-  reactive({
  #   k3 %>%
  #     filter(
  #       k3$number == input$number_zyq &
  #         k3$nianji == input$nianji_zyq &
  #         k3$exam_numname == input$type_zyq &
  #         k3$range == input$fanwei_zyq
  #     ) %>%
  #     select(class_Name)
  # })
  
  reorder_size <- function(x) {
    factor(x, levels = names(sort(table(x), decreasing = TRUE)))
  }
  # output$zf_zyq <-  renderPlot({
  #   ggplot(data = datainput4_zyq(), aes(x = reorder_size(class_Name), fill =
  #                                         class_Name)) +
  #     geom_bar(stat = 'count',
  #              position = "dodge",
  #              width = 0.5) +
  #     ylab("人数") +
  #     xlab("班级")
  #   
  # })
  output$baocuo3zyq<-renderText({
    datainput4_zyq <- 
      k3 %>%
      filter(
        k3$number == input$number_zyq &
          k3$nianji == input$nianji_zyq &
          k3$exam_numname == input$type_zyq &
          k3$range == input$fanwei_zyq
      ) %>%
      select(class_Name)
    
    if (is.na(datainput4_zyq[1, 1]) == T) {
      return(paste0('此条件无匹配结果（数据不完整）'))
    }
  })
  
  output$zf_zyq <-  renderPlot({
    
    datainput4_zyq <- 
      k3 %>%
      filter(
        k3$number == input$number_zyq &
          k3$nianji == input$nianji_zyq &
          k3$exam_numname == input$type_zyq &
          k3$range == input$fanwei_zyq
      ) %>%
      select(class_Name)
    
    if(is.na(datainput4_zyq[1,1])==F){return(ggplot(data = datainput4_zyq, aes(x = reorder_size(class_Name), fill =
                                                                                 class_Name)) +
                                               geom_bar(stat = 'count',
                                                        position = "dodge",
                                                        width = 0.5) +
                                               ylab("人数") +
                                               xlab("班级")+
                                               theme(axis.text.x=element_text(angle=60,hjust=1))
    )}
    
  })
  #---------kaoqin--------------
  datasetInputsky <- eventReactive(input$update, {
    mydatasky[mydatasky$qj_term == input$'学期' & mydatasky$cla_Name1 == input$'年级',]
  }, ignoreNULL = FALSE)
  
  mydatasetInputsky <- eventReactive(input$update, {
    mydatasky[mydatasky$qj_term == input$'学期',]
  }, ignoreNULL = FALSE)
  
  datasetInputsky1 <- eventReactive(input$update, {
    mydatasky[mydatasky$qj_term == input$'学期' & mydatasky$cla_Name1 == input$'年级'& mydatasky$cla_Name == input$'班级',]
  }, ignoreNULL = FALSE)
  output$'本班未穿校服人数' <- renderInfoBox({
    infoBox( 
      '本班未穿校服人数', paste0(dim(filter(mydatasky,qj_term==input$"学期",cla_Name1==input$"年级",cla_Name == input$'班级',control_task_order_id==c(9900200,200100)))[1]),
      color = "light-blue",fill = FALSE
    )
  })
  output$'本班课间操请假人数' <- renderInfoBox({
    infoBox( 
      '本班课间操请假人数', paste0(dim(filter(mydatasky,qj_term==input$"学期",cla_Name1==input$"年级",cla_Name == input$'班级',control_task_order_id==300200))[1]),
      color = "light-blue",fill = FALSE
    )
  })
  output$'本班请假离校人数' <- renderInfoBox({
    infoBox( 
      '本班请假离校人数', paste0(dim(filter(mydatasky,qj_term==input$"学期",cla_Name1==input$"年级",cla_Name == input$'班级',control_task_order_id==200200))[1]),
      color = "light-blue",fill = FALSE
    )
  })
  output$'本班未戴校徽人数' <- renderInfoBox({
    infoBox( 
      '本班未戴校徽人数', paste0(dim(filter(mydatasky,qj_term==input$"学期",cla_Name1==input$"年级",cla_Name == input$'班级',control_task_order_id==200100))[1]),
      color = "light-blue",fill = FALSE
    )
  })
  output$'全校缺勤人数' <- renderInfoBox({
    infoBox( 
      '本学期全校缺勤人数', paste0(dim(filter(mydatasky,qj_term==input$"学期")[1])),
      color = "light-blue",fill = FALSE
    )
  })     
  output$'年级早退比例' <- renderInfoBox({
    infoBox(
      '本年级早退比例', paste0(round(dim(filter(mydatasky,qj_term==input$"学期",ControllerID==c(1002,99003))[1])
                              /dim(filter(mydatasky,qj_term==input$"学期")[1])*100,digits = 3),"%"), 
      color = "light-blue",fill = FALSE
    )
  })
  output$'年级迟到比例' <- renderInfoBox({
    infoBox(
      '本年级迟到比例', paste0(round(dim(filter(mydatasky,qj_term==input$"学期",ControllerID==c(1001,99001))[1])/
                                dim(filter(mydatasky,qj_term==input$"学期")[1])*100,digits = 3),"%"
      ), 
      color = "light-blue",fill = FALSE
    ) 
  })
  output$'本年级缺勤人数' <- renderInfoBox({
    infoBox(
      '本年级缺勤人数', paste0(" ",dim(filter(mydatasky,qj_term==input$"学期",cla_Name1==input$"年级",ControllerID==c(1002,99002,99003))[1])), 
      color = "light-blue",fill = FALSE
    )
  })
  output$attendanceleixing<-renderPlot({
    ggplot(data = datasetInputsky())+ 
      geom_bar(mapping = aes(x=controler_name.x),fill="#FF6666") + 
      labs(x="考勤类型",y="人数(单位：人)")
  })
  output$attendanceqingkuang<-renderPlot({
    ggplot(data = mydatasetInputsky(),aes(x=cla_Name1,fill=controler_name.x)) + 
      geom_bar(position = "dodge") + 
      labs(x="三个年级考勤情况",y="人数(单位：人)",fill="考勤情况")
  })
  
  output$'本班缺勤人数' <- renderInfoBox({
    infoBox(
      '本班缺勤人数', paste0(dim(filter(mydatasky,qj_term==input$"学期",cla_Name1==input$"年级",cla_Name==input$"班级",ControllerID==c(1002,99002,99003))[1])), 
      color = "light-blue",fill = FALSE
    )
  })
  output$'本班迟到人数' <- renderInfoBox({
    infoBox(
      '本班迟到人数', paste0(dim(filter(mydatasky,qj_term==input$"学期",cla_Name1==input$"年级",cla_Name==input$"班级",ControllerID==c(1001,99001))[1])), 
      color = "light-blue",fill = FALSE
    )
  })
  output$banjikaoqin<-renderPlot({
    ggplot(data = datasetInputsky1())+ 
      geom_bar(mapping = aes(x=controler_name.x),fill="#3399CC") + 
      labs(x="考勤类型",y="人数(单位：人)")
  })
  output$gebanjikaoqin<-renderPlot({
    ggplot(data = datasetInputsky(), aes(x = cla_Name, fill = controler_name.x)) +
      geom_bar(position = "dodge") +
      labs(x = "各班级考勤情况", y = "人数(单位：人)", fill = "考勤情况")
  })
  #----------CLASS_1-----
  datasetInput <- eventReactive(input$updatey1, {
    test[test$cla_Name == input$class_namey1 &
           test$exam_numname == input$ksy1 &
           test$mes_sub_name == input$kmy1 ,]
  }, ignoreNULL = FALSE)
  
  datasetInput1 <- eventReactive(input$updatey1, {
    test[test$exam_numname == input$ksy1 &
           test$mes_sub_name == input$kmy1 ,]
  }, ignoreNULL = FALSE)
  
  datasetInput2 <- eventReactive(input$updatey1, {
    test[test$cla_Name == input$class_namey1,]
  }, ignoreNULL = FALSE)
  
  datasetInput3 <- eventReactive(input$updatey1, {
    test131[test131$班级  == input$class_namey1 &
              test131$考试  == input$ksy1,]
  }, ignoreNULL = FALSE)
  
  datasetInput4 <- eventReactive(input$updatey1, {
    test131[test131$考试  == input$ksy1,]
  }, ignoreNULL = FALSE)
  
  datasetInput5 <- eventReactive(input$updatey1, {
    test231[test231$考试  == input$ksy1 &
              test231$科目  == input$kmy1 ,]
  }, ignoreNULL = FALSE)
  
  ###新加的输入数据
  datasetInput6 <- eventReactive(input$updatey1, {
    test131[test131$班级 == input$class_namey1 &
              test131$考试  == input$ksy1,]
  }, ignoreNULL = FALSE)
  
  datasetInput7 <- eventReactive(input$updatey1, {
    test151[test151$班级  == input$class_namey1 &
              test151$考试  == input$ksy1 &
              test151$科目  == input$kmy1 ,]
  }, ignoreNULL = FALSE)
  
  
  output$cj <- renderPlot({
    ggplot(data = datasetInput()) +
      geom_point(mapping = aes(x = StudentID, y = mes_Score, colour = level)) +
      geom_hline(data = datasetInput(),
                 aes(yintercept = as.numeric(mean(
                   datasetInput()$mes_Score
                 ))),
                 color = 'red') +
      geom_hline(data = datasetInput1(),
                 aes(yintercept = as.numeric(mean(
                   datasetInput1()$mes_Score
                 ))),
                 color = 'blue') +
      ylab("成绩 (单位：分)") +
      xlab("学生学号")
  })
  
  
  output$table <-  DT::renderDataTable({
    DT::datatable(datasetInput6())
  })
  
  output$tabled <-  DT::renderDataTable({
    DT::datatable(datasetInput7())
  })
  
  
  output$'班级最高分' <- renderInfoBox({
    infoBox('班级最高分',
            paste0("班级最高分", max(datasetInput()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  
  output$'班级最低分' <- renderInfoBox({
    infoBox('班级最低分',
            paste0("班级最低分", min(datasetInput()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'班级平均分' <- renderInfoBox({
    infoBox('班级平均分',
            paste0("班级平均分", mean(datasetInput()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'班级方差' <- renderInfoBox({
    infoBox('班级方差',
            paste0("班级方差", var(datasetInput()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'班级标准差' <- renderInfoBox({
    infoBox('班级标准差',
            paste0("班级标准差", sd(datasetInput()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'年级平均分' <- renderInfoBox({
    infoBox('年级平均分',
            paste0("年级平均分", mean(datasetInput1()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  
  output$'总分最高分' <- renderInfoBox({
    infoBox('总分最高分',
            paste0("总分最高分", max(datasetInput3()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  
  output$'总分最低分' <- renderInfoBox({
    infoBox('总分最低分',
            paste0("总分最低分", min(datasetInput3()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'总分平均分' <- renderInfoBox({
    infoBox('总分平均分',
            paste0("总分平均分", mean(datasetInput3()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'总分方差' <- renderInfoBox({
    infoBox('总分方差',
            paste0("方差", var(datasetInput3()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'总分标准差' <- renderInfoBox({
    infoBox('总分标准差',
            paste0("总分标准差", sd(datasetInput3()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'年级总分平均分' <- renderInfoBox({
    infoBox('年级总分平均分',
            paste0("年级总分平均分", mean(datasetInput4()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  
  output$sum <- renderPlot({
    ggplot(data = datasetInput3()) +
      geom_point(mapping = aes(x =  学生学号, y =  总分)) +
      geom_hline(data = datasetInput3(),
                 aes(yintercept = as.numeric(mean(
                   datasetInput3()$总分
                 ))),
                 color = 'red') +
      geom_hline(data = datasetInput4(),
                 aes(yintercept = as.numeric(mean(
                   datasetInput4()$总分
                 ))),
                 color = 'blue') +
      ylab("总分 (单位：分)") +
      xlab("学生学号")
  })
  output$gmean <- renderPlot({
    ggplot(data = datasetInput5(), mapping = (aes(
      x = 班级 ,
      y = 平均分,
      fill =  班级,
      group = factor(1)
    ))) +
      geom_bar(stat = "identity", width = 0.5) +
      geom_text(aes(label =  班级)) +
      coord_flip() +
      ylab("平均分(单位：分)") +
      xlab("班级名称")
  })
  ##新加的等第box
  output$dd <- renderPlot({
    ggplot(data = datasetInput1()) +
      geom_bar(mapping = (aes(x = cla_Name, fill = level))) +
      coord_flip() +
      xlab("班级名称")
  })
  #------------CLASS_2-----------
  
  
  datasetInputy2 <- eventReactive(input$updatey2,{
    test1[test1$cla_Name==input$class_namey2 & test1$exam_numname == input$ksy2& test1$mes_sub_name == input$kmy2 ,]
  },ignoreNULL = FALSE)
  
  datasetInput21 <- eventReactive(input$updatey2,{
    test1[test1$exam_numname == input$ksy2 & test1$mes_sub_name == input$kmy2 ,]
  },ignoreNULL = FALSE)
  
  datasetInput22 <- eventReactive(input$updatey2,{
    test1[test1$cla_Name==input$class_namey2,]
  },ignoreNULL = FALSE)
  
  datasetInput23<-eventReactive(input$updatey2,{
    test132[test132$班级==input$class_namey2 & test132$考试== input$ksy2,]
  },ignoreNULL = FALSE)
  
  datasetInput24<-eventReactive(input$updatey2,{
    test132[ test132$考试 == input$ksy2,]
  },ignoreNULL = FALSE)
  
  datasetInput25<-eventReactive(input$updatey2,{
    test232[test232$考试== input$ksy2& test232$科目 == input$kmy2 ,]
  },ignoreNULL = FALSE)
  
  datasetInput26 <- eventReactive(input$updatey2,{
    test132[test132$班级==input$class_namey2 & test132$考试 == input$ksy2,]
  },ignoreNULL = FALSE)
  
  datasetInput27 <- eventReactive(input$updatey2,{
    test152[test152$班级==input$class_namey2 & test152$考试== input$ksy2 &test152$科目 == input$kmy2 ,]
  },ignoreNULL = FALSE)
  
  output$cjy2 <-renderPlot({
    ggplot(data = datasetInputy2()) + 
      geom_point(mapping = aes(x=StudentID, y=mes_Score,colour=level)) + 
      geom_hline(data = datasetInputy2(),aes(yintercept=as.numeric(mean(datasetInputy2()$mes_Score))),color='red')+
      geom_hline(data = datasetInput21(),aes(yintercept=as.numeric(mean(datasetInput21()$mes_Score))),color='blue')+
      ylab("成绩 (单位：分)") + 
      xlab("学生学号") 
  })
  output$tabley2 <-  DT::renderDataTable({
    DT::datatable(datasetInput26())
  })
  
  output$tabledy2 <-  DT::renderDataTable({
    DT::datatable(datasetInput27())
  })
  output$ddy2 <-renderPlot({
    ggplot(data = datasetInput21())+
      geom_bar(mapping=(aes(x=cla_Name,fill=level))) +
      coord_flip()+
      xlab("班级名称") 
  })
  
  output$'班级最高分y2'<-renderInfoBox({
    infoBox('班级最高分',paste0("班级最高分",max(datasetInputy2()$mes_Score)),color = "light-blue",fill = FALSE)
  })
  
  output$'班级最低分y2'<-renderInfoBox({
    infoBox('班级最低分',paste0("班级最低分",min(datasetInputy2()$mes_Score)),color = "light-blue",fill = FALSE)
  })
  output$'班级平均分y2'<-renderInfoBox({
    infoBox('班级平均分',paste0("班级平均分",mean(datasetInputy2()$mes_Score)),color = "light-blue",fill = FALSE)
  })
  output$'班级方差y2'<-renderInfoBox({
    infoBox('班级方差',paste0("班级方差",var(datasetInputy2()$mes_Score)),color = "light-blue",fill = FALSE)
  })
  output$'班级标准差y2'<-renderInfoBox({
    infoBox('班级标准差',paste0("班级标准差",sd(datasetInputy2()$mes_Score)),color = "light-blue",fill = FALSE)
  })
  output$'年级平均分y2'<-renderInfoBox({
    infoBox('年级平均分',paste0("年级平均分",mean(datasetInput21()$总分)),color = "light-blue",fill = FALSE)
  })
  
  
  output$'总分最高分y2'<-renderInfoBox({
    infoBox('总分最高分',paste0("总分最高分",max(datasetInput23()$总分)),color = "light-blue",fill = FALSE)
  })
  
  output$'总分最低分y2'<-renderInfoBox({
    infoBox('总分最低分',paste0("总分最低分",min(datasetInput23()$总分)),color = "light-blue",fill = FALSE)
  })
  output$'总分平均分y2'<-renderInfoBox({
    infoBox('总分平均分',paste0("总分平均分",mean(datasetInput23()$总分)),color = "light-blue",fill = FALSE)
  })
  output$'总分方差y2'<-renderInfoBox({
    infoBox('总分方差',paste0("方差",var(datasetInput23()$总分)),color = "light-blue",fill = FALSE)
  })
  output$'总分标准差y2'<-renderInfoBox({
    infoBox('总分标准差',paste0("总分标准差",sd(datasetInput23()$总分)),color = "light-blue",fill = FALSE)
  })
  output$'年级总分平均分y2'<-renderInfoBox({
    infoBox('年级总分平均分',paste0("年级总分平均分",mean(datasetInput24()$总分)),color = "light-blue",fill = FALSE)
  })
  
  output$sumy2 <-renderPlot({
    ggplot(data = datasetInput23())+ 
      geom_point(mapping = aes(x=学生学号, y=总分)) +  
      geom_hline(data = datasetInput23(),aes(yintercept=as.numeric(mean(datasetInput23()$总分))),color='red')+
      geom_hline(data = datasetInput24(),aes(yintercept=as.numeric(mean(datasetInput24()$总分))),color='blue')+
      ylab("总分 (单位：分)") + 
      xlab("学生学号") 
  })
  output$gmeany2 <-renderPlot({
    ggplot(data = datasetInput25(),mapping=(aes(x=班级,y=平均分,fill=班级,group=factor(1)))) + 
      geom_bar(stat="identity",width=0.5) + 
      geom_text(aes(label = 班级)) +
      coord_flip()+
      ylab("平均分(单位：分)") + 
      xlab("班级名称") 
  })
  
  
  #---------CLASS_3-----
  datasetInputy3 <- eventReactive(input$updatey3,{
    test2[test2$cla_Name==input$class_namey3 & test2$exam_numname == input$ksy3& test2$mes_sub_name == input$kmy3 ,]
  },ignoreNULL = FALSE)
  
  datasetInput31 <- eventReactive(input$updatey3,{
    test2[test2$exam_numname == input$ksy3 & test2$mes_sub_name == input$kmy3 ,]
  },ignoreNULL = FALSE)
  
  datasetInput32 <- eventReactive(input$updatey3,{
    test2[test2$cla_Name==input$class_namey3,]
  },ignoreNULL = FALSE)
  
  datasetInput33<-eventReactive(input$updatey3,{
    test133[test133$班级==input$class_namey3 & test133$考试== input$ksy3,]
  },ignoreNULL = FALSE)
  
  datasetInput34<-eventReactive(input$updatey3,{
    test133[ test133$考试 == input$ksy3,]
  },ignoreNULL = FALSE)
  
  datasetInput35<-eventReactive(input$updatey3,{
    test233[test233$考试== input$ksy3& test233$科目 == input$kmy3 ,]
  },ignoreNULL = FALSE)
  
  datasetInput36 <- eventReactive(input$updatey3,{
    test133[test133$班级==input$class_namey3& test133$考试 == input$ksy3,]
  },ignoreNULL = FALSE)
  
  datasetInput37 <- eventReactive(input$updatey3,{
    test153[test153$班级==input$class_namey3 & test153$考试== input$ksy3 &test153$科目 == input$kmy3 ,]
  },ignoreNULL = FALSE)
  
  output$cjy3 <- renderPlot({
    ggplot(data = datasetInputy3()) +
      geom_point(mapping = aes(x = StudentID, y = mes_Score, colour = level)) +
      geom_hline(data = datasetInputy3(),
                 aes(yintercept = as.numeric(mean(
                   datasetInputy3()$mes_Score
                 ))),
                 color = 'red') +
      geom_hline(data = datasetInput31(),
                 aes(yintercept = as.numeric(mean(
                   datasetInput31()$mes_Score
                 ))),
                 color = 'blue') +
      ylab("成绩 (单位：分)") +
      xlab("学生学号")
  })
  
  
  output$tabley3<-  DT::renderDataTable({
    DT::datatable(datasetInput36())
  })
  
  output$tabledy3 <-  DT::renderDataTable({
    DT::datatable(datasetInput37())
  })
  
  output$'班级最高分y3' <- renderInfoBox({
    infoBox('班级最高分',
            paste0("班级最高分", max(datasetInputy3()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  
  output$'班级最低分y3' <- renderInfoBox({
    infoBox('班级最低分',
            paste0("班级最低分", min(datasetInputy3()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'班级平均分y3' <- renderInfoBox({
    infoBox('班级平均分',
            paste0("班级平均分", mean(datasetInputy3()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'班级方差y3' <- renderInfoBox({
    infoBox('班级方差',
            paste0("班级方差", var(datasetInputy3()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'班级标准差y3' <- renderInfoBox({
    infoBox('班级标准差',
            paste0("班级标准差", sd(datasetInputy3()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'年级平均分y3' <- renderInfoBox({
    infoBox('年级平均分',
            paste0("年级平均分", mean(datasetInput31()$mes_Score)),
            color = "light-blue",
            fill = FALSE)
  })
  
  
  output$'总分最高分y3' <- renderInfoBox({
    infoBox('总分最高分',
            paste0("总分最高分", max(datasetInput33()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  
  output$'总分最低分y3' <- renderInfoBox({
    infoBox('总分最低分',
            paste0("总分最低分", min(datasetInput33()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'总分平均分y3' <- renderInfoBox({
    infoBox('总分平均分',
            paste0("总分平均分", mean(datasetInput33()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'总分方差y3' <- renderInfoBox({
    infoBox('总分方差',
            paste0("方差", var(datasetInput33()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'总分标准差y3' <- renderInfoBox({
    infoBox('总分标准差',
            paste0("总分标准差", sd(datasetInput33()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  output$'年级总分平均分y3' <- renderInfoBox({
    infoBox('年级总分平均分',
            paste0("年级总分平均分", mean(datasetInput34()$总分)),
            color = "light-blue",
            fill = FALSE)
  })
  
  output$sumy3 <- renderPlot({
    ggplot(data = datasetInput33()) +
      geom_point(mapping = aes(x = 学生学号, y = 总分)) +
      geom_hline(data = datasetInput33(),
                 aes(yintercept = as.numeric(mean(
                   datasetInput33()$总分
                 ))),
                 color = 'red') +
      geom_hline(data = datasetInput34(),
                 aes(yintercept = as.numeric(mean(
                   datasetInput34()$总分
                 ))),
                 color = 'blue') +
      ylab("总分 (单位：分)") +
      xlab("学生学号")
  })
  output$gmeany3 <- renderPlot({
    ggplot(data = datasetInput35(), mapping = (aes(
      x = 班级,
      y = 平均分,
      fill = 班级,
      group = factor(1)
    ))) +
      geom_bar(stat = "identity", width = 0.5) +
      geom_text(aes(label =  平均分)) +
      coord_flip() +
      ylab("平均分(单位：分)") +
      xlab("班级名称")
  })
  
  output$ddy3 <- renderPlot({
    ggplot(data = datasetInput31()) +
      geom_bar(mapping = (aes(x = cla_Name, fill = level))) +
      coord_flip() +
      xlab("班级名称")
  })
  
  #----student-------
  output$shengfen <- renderEChart({
    shengfen <- data.table::fread('./shengfen.csv', encoding = 'UTF-8')
    shengfen <- as.data.frame(shengfen)
    shengfen$人数  <- as.numeric(shengfen$人数)
    b <- data.frame('浙江', 120.50, 29.9)
    b$X.浙江. <- as.character(b$X.浙江.)
    echartr(shengfen, 省份,  人数, type = 'map_china') %>%
      setDataRange(
        splitNumber = 0,
        valueRange = range(shengfen[, 2]),
        color = c('red', 'orange', 'yellow', 'limegreen', 'green')
      ) %>%
      setToolbox(show = FALSE) %>%
      setLegend(show = FALSE) %>%
      addMP(
        series = '浙江',
        data = data.frame(name = '浙江', value = 1368),
        symbol = 'emptyCircle',
        symbolSize = 10,
        effect = list(show = T)
      ) %>%
      addGeoCoord(b) %>%
      addMP(
        shengfen[1:16, c("省份", "人数")],
        symbolSize = 5,
        itemStyle = list(
          normal = list(
            borderColor = '#87cefa',
            borderWidth = 1,
            label = list(show = F)
          ),
          emphasis = list(
            borderColor = '#1e90ff',
            borderWidth = 5,
            label = list(show = F)
          )
        )
      ) %>%
      addGeoCoord(shengfen[1:16, c('省份', 'lng', 'lat')])
  })
  
  output$dishi <- renderEChart({
    dishi <- data.table::fread('./dishi.csv', encoding = 'UTF-8')
    dishi <- as.data.frame(dishi)
    a <- data.frame('宁波市', 121.56, 29.8)
    a$X.宁波市. <- as.character(a$X.宁波市.)
    echartr(dishi, 地市, 人数, type = 'map_china', subtype = '浙江') %>%
      setDataRange(
        splitNumber = 0,
        valueRange = range(dishi[, 2]),
        color = c('red', 'orange', 'yellow', 'limegreen', 'green')
      ) %>%
      setToolbox(show = FALSE) %>%
      setLegend(show = FALSE) %>%
      addMP(
        series = '宁波',
        data = data.frame(name = '宁波市', value = 1101),
        symbol = 'emptyCircle',
        symbolSize = 10,
        effect = list(show = T)
      ) %>%
      addGeoCoord(a)
  })
  
  
  output$nannv <- renderEChart({
    nannv <- data.table::fread('./nannv.csv', encoding = 'UTF-8')
    nannv <- as.data.frame(nannv)
    echartr(nannv,  性别,  人数, t = 年级, type = 'ring') %>%
      setToolbox(show = FALSE)
  })
  
  output$plot4_xjx <- renderImage({
    list(
      src = "./week.png",
      filetype = "image/png",
      alt = "This is a girl",
      width = 550,
      height = 350
    )
  }, deleteFile = FALSE)
  
  output$plot5_xjx <- renderImage({
    list(
      src = "./month.png",
      filetype = "image/png",
      alt = "This is a girl",
      width = 550,
      height = 350
    )
  }, deleteFile = FALSE)
  
  output$yx_w <- renderEChart({
    sg_x <- sg[(sg['exam_numname']==input$'ks_w') & (sg['gra_Name']==input$'nj_w'),]
      sg_n <- round(dim(sg_x)[1]*0.05)
      sg_g <- if(sg_n==0){
        sg_g = 0
      }else{
        sg_g = sg_x[sg_x['grade_ranking']<=sg_n,]
      }
      cia <- '该条件下无考试'
      Freqa <- 1000
      if(length(sg_g)==0 | sg_g == 0){
            echartr(data.frame(cia,Freqa), cia, Freqa, type='wordCloud')
          }else{
            echartr(sg_g,详情,score, type='treemap')%>%
              setLegend(show = F)%>%
              setToolbox(show = F)
          }
  })
  
  output$bjmd_w <- renderEChart({
    sg_b <- sg[sg['cla_Name_x']==input$bj_w,]
    echartr(sg_b, c(bf_Name, cla_Name_x), weight, weight, type='force')%>%
      setLegend(show = F)%>%
      setToolbox(show = F)
  })
  
  
  datasetInput3qyt <- reactive({
    class_compareqyt[
      class_compareqyt$'grade'==input$dataset&class_compareqyt$'subject' == input$'subject'&class_compareqyt$'exam_numname'==input$'exam_numname',]})

  
  output$echart1qyt<- renderEChart({
    ci <- '本年级没有本次考试的成绩'
    Freqa <- 1000
    datasetInput3qyt <- class_compareqyt[
      class_compareqyt$'grade'==input$dataset&class_compareqyt$'subject' == input$'subject'&class_compareqyt$'exam_numname'==input$'exam_numname',]
    if(is.na(datasetInput3qyt[1,1])==F){return(
      echartr(datasetInput3qyt, 'level', 'number', 'exam_class', type='vbar')%>% setSymbols('emptycircle')%>%
        setToolbox(pos = 2)
    )}else{
      echartr(data.frame(ci,Freqa), ci, Freqa, type='wordCloud')}
  })
  
  
  #----great--------
}

shinyApp(ui = ui, server = server)

